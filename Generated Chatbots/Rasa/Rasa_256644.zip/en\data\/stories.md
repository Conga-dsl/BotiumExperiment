## path_0
* greet	
	- utter_greet_text
* name_entry	
	- utter_show_name_country_text

## path_1
* goodbye	
	- utter_goodbye_text
	- utter_nyc_text

## path_2
* mission	
	- utter_mission_text
	- utter_goodbye_text

## path_3
* info	
	- utter_info_text
	- utter_goodbye_text

## path_4
* faculty	
	- utter_faculty_text
	- utter_goodbye_text

## path_5
* student	
	- utter_student_text
	- utter_goodbye_text

## path_6
* placement	
	- utter_placement_text
	- utter_goodbye_text

## path_7
* results	
	- utter_results_img
	- utter_goodbye_text

## path_8
* facility	
	- utter_facility_text
	- utter_goodbye_text

## path_9
* hod	
	- utter_hod_text
	- utter_goodbye_text

