## path_0
* greet	
	- utter_greet_text
* mood_great	
	- utter_happy_text

## path_1
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* affirm	
	- utter_happy_text
* greet	
	- utter_goodbye_text

## path_2
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* deny	
	- utter_goodbye_text

## path_3
* goodbye	
	- utter_goodbye_text

## path_4
* FallbackIntent	
	- utter_default_text

