## path_0
* greet	
	- utter_greet_text
* mood_great	
	- utter_happy_text

## path_1
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* affirm	
	- utter_happy_text

## path_2
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* deny	
	- utter_goodbye_text

## path_3
* greet	
	- utter_greet_text
* monthly_expenses	
	- action_Email_empty
	- action_Whatsapp_empty
	- utter_monthly_expenses_img
* goodbye	
	- utter_goodbye_text

## path_4
* goodbye	
	- utter_goodbye_text

## path_5
* bot_challenge	
	- utter_iamabot_text

## path_6
* FallbackIntent	
	- utter_default_text

