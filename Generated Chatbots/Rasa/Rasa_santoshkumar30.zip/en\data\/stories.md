## path_0
* greet	
	- utter_greet_text
* mood_great	
	- utter_happy_text

## path_1
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* affirm	
	- utter_happy_text

## path_2
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* deny	
	- utter_goodbye_text

## path_3
* goodbye	
	- utter_goodbye_text

## path_4
* bot_challenge	
	- utter_iamabot_text

## path_5
* customer_query	
	- utter_slots_values_text

## path_6
* ask_howdoing	
	- utter_ask_howdoing_text

## path_7
* ask_builder	
	- utter_ask_builder_text

## path_8
* ask_languagesbot	
	- utter_ask_languagesbot_text

## path_9
* ask_howold	
	- utter_ask_howold_text

