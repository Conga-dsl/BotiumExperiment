## path_0
* datawranglinganddatacleaning	
	- utter_data_wrangling_and_data_cleaning_text

## path_1
* unbalancedbinaryclassification	
	- utter_unbalanced_binary_classification_text

## path_2
* boxplotandhistogram	
	- utter_box_plot_and_histogram_text

## path_3
* regularizationmethods	
	- utter_regularization_methods_text

## path_4
* NeuralNetwork	
	- utter_Neural_Network_text

## path_5
* cross-validation	
	- utter_cross-validation_text

## path_6
* selectmetrics	
	- utter_select_metrics_text

## path_7
* precisionandrecall	
	- utter_precision_and_recall_text

## path_8
* falsepositiveandfalsenegative	
	- utter_false_positive_and_false_negative_text

## path_9
* supervisedlearningandunsupervisedlearning	
	- utter_supervised_learning_and_unsupervised_learning_text

## path_10
* generateapredictivemodelusingmultipleregression	
	- utter_generate_a_predictive_model_using_multiple_regression_text

## path_11
* NLPstandfor	
	- utter_NLP_stand_for_text

## path_12
* randomforestsVsSVM	
	- utter_random_forests_Vs_SVM_text

## path_13
* dimensionreduction	
	- utter_dimension_reduction_text

## path_14
* NaivesBayes	
	- utter_Naives_Bayes_text

## path_15
* drawbacksoflinearmodel	
	- utter_drawbacks_of_linear_model_text

## path_16
* collinearity	
	- utter_collinearity_text

## path_17
* regressionmodel	
	- utter_regression_model_text

## path_18
* decisiontree	
	- utter_decision_tree_text

## path_19
* randomforest	
	- utter_random_forest_text
	- utter_random_forests_Vs_SVM_text

## path_20
* kernel	
	- utter_kernel_text

## path_21
* overfitting	
	- utter_overfitting_text

## path_22
* boosting	
	- utter_boosting_text

## path_23
* Markowchains	
	- utter_Markow_chains_text

## path_24
* statisticalsignificance	
	- utter_statistical_significance_text

## path_25
* CentralLimitTheorem	
	- utter_Central_Limit_Theorem_text

## path_26
* statisticalpower	
	- utter_statistical_power_text

## path_27
* outlier	
	- utter_outlier_text

## path_28
* missingdata	
	- utter_missing_data_text

## path_29
* rootcauseanalysis	
	- utter_root_cause_analysis_text

## path_30
* LawofLargeNumbers	
	- utter_Law_of_Large_Numbers_text

## path_31
* controlbiases	
	- utter_control_biases_text

## path_32
* confoundingvariables	
	- utter_confounding_variables_text

## path_33
* AdivBtesting	
	- utter_A_div_B_testing_text

## path_34
* qualityassurance	
	- utter_quality_assurance_text

## path_35
* greet	
	- utter_greet_text
* mood_great	
	- utter_happy_text

## path_36
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* affirm	
	- utter_happy_text

## path_37
* greet	
	- utter_greet_text
* mood_unhappy	
	- utter_cheer_up_img
	- utter_did_that_help_text
* deny	
	- utter_goodbye_text

## path_38
* goodbye	
	- utter_goodbye_text

## path_39
* bot_challenge	
	- utter_iamabot_text

