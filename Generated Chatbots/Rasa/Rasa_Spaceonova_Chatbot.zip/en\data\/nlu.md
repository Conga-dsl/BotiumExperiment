## intent:greet
- hey 
- hello 
- hi 
- good morning 
- good evening 
- hey there 
- hello there 
- moin 
- hey there 
- let's go 
- hey dude 
- goodmorning 
- goodevening 
- good afternoon 
- hi folks 
- hi again 
- hii 
- hi folks 
- hi Mister 
- hi pal! 
- hi there 
- greetings 
- hello everybody 
- hello is anybody there 
- hello robot 
- who are you? 
- what are you? 
- what's up 
- how do you do? 
## intent:goodbye
- bye 
- goodbye 
- see you around 
- see you later 
- good afternoon 
- cu 
- good by 
- cee you later 
- good night 
- bye 
- goodbye 
- have a nice day 
- see you around 
- bye bye 
- see you later 
- gotta well 
- farewell 
- bbyee 
- byeeeee 
- take care 
- i'm off 
- see you later alligator 
- we'll speak soon 
- end 
- finish 
- bye for now 
- see you 
- gotta go 
- catch you later 
## intent:thank
- Thanks 
- Thank you 
- Thank you so much 
- Thanks bot 
- Thanks for that 
- cheers- intent: thank 
- Thanks 
- Thank you 
- Thank you so much 
- Thanks bot 
- Thanks for that 
- cheers 
## intent:bot_challenge
- are you a bot? 
- are you a human? 
- am I talking to a bot? 
- am I talking to a human? 
## intent:spaceonova_intro
- what is spaceonova? 
- what does spaceonova do? 
- about spaceonova? 
- can you tell me about spaceonva? 
- tell me about spaceonova organisation? 
- what is this organisaton for? 
- what is the purpose of this organisation? 
## intent:about_people
- who is ceo? 
- who is the ceo of organisation? 
- ceo 
## intent:courses
- name some courses 
- what courses do spaceonova provide? 
- what courses this organisation teach? 
- which type of courses do you teach? 
- what are some training programmes? 
- training programmes 
- courses 
- name some training programmes 
- name some master classes 
- masterclass 
- master class 
## intent:corona_intro
- What is corona virus 
- what is covid 
- what is a novel corona virus 
- what is covid-19 
- tell me about corona 
- can you tell me about covid 
## intent:corona_spread
- how does corona virus spread 
- how does the virus spread 
## intent:corona_food_spread
- Does corona spread from food 
- how will corona spread from food 
## intent:warm_weather
- will warm weather stop the spread 
- will it stop with warm weather 
## intent:high_risk
- who is at a higher risk of infection 
## intent:affirm
- yes 
- y 
- indeed 
- of course 
- that sounds good 
- correct 
## intent:deny
- no 
- n 
- never 
- I don't think so 
- don't like that 
- no way 
- not really 
## intent:mood_great
- perfect 
- great 
- amazing 
- feeling like a king 
- wonderful 
- I am feeling very good 
- I am great 
- I am amazing 
- I am going to save the world 
- super stoked 
- extremely good 
- so so perfect 
- so good 
- so perfect 
## intent:mood_unhappy
- my day was horrible 
- I am sad 
- I don't feel very well 
- I am disappointed 
- super sad 
- I'm so sad 
- sad 
- very sad 
- unhappy 
- not good 
- not very good 
- extremly sad 
- so saad 
- so sad 

