## path_0
* greet	
	- utter_greet_text

## path_1
* mood_great	
	- utter_happy_text

## path_2
* mood_unhappy	
	- utter_cheer_up_img

## path_3
* thank	
	- utter_welcome_text

## path_4
* goodbye	
	- utter_goodbye_text

## path_5
* bot_challenge	
	- utter_iamabot_text

## path_6
* spaceonova_intro	
	- utter_intro_text

## path_7
* about_people	
	- utter_people_text

## path_8
* corona_intro	
	- utter_corona_intro_text

## path_9
* corona_spread	
	- utter_corona_spread_text

## path_10
* corona_food_spread	
	- utter_corona_food_spread_text

## path_11
* warm_weather	
	- utter_warm_weather_text

## path_12
* high_risk	
	- utter_high_risk_text

## path_13
* courses	
	- utter_courses_text

