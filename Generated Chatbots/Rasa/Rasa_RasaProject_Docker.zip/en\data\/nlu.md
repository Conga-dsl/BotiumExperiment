## intent:greet
- hey 
- hello 
- hi 
- good morning 
- good evening 
- hey there 
## intent:open_position
- Iâ€™d like to know which positions are open right now. 
- I want to know the available positions now. 
- I would like to know the open positions. 
- I would like to know the available positions. 
- Would you please write me the open positions at RASA 
- Iâ€™d like to know what are the open positions now at RASA. 
- What are the available positions now? 
## intent:role
- A  [technical]{"entity": "role_role_type" }  one 
- A  [tech]{"entity": "role_role_type" }  position 
- A  [business]{"entity": "role_role_type" }  one 
## intent:job_status
- Hi, my name is  [Ali]{"entity": "job_status_PERSON" }  Park. I applied for a job and would like to know when Iâ€™ll hear back. 
- Hey i am  [Sebastian]{"entity": "job_status_PERSON" }  Pork, i applied for a job and would like to check my application. 
- Hi, i am  [Michal]{"entity": "job_status_PERSON" } . I applied for a job and would like to know when Iâ€™ll hear back. 
- Hi, Iâ€™m  [Kristian]{"entity": "job_status_PERSON" } . I would like to check the status of my application. 
- Hi, my name is  [William]{"entity": "job_status_PERSON" } . I want to know my application status. 
- Hi, my name is  [Chris]{"entity": "job_status_PERSON" } . I applied for a job and would like to know when Iâ€™ll hear back. 
## intent:bot_challenge
- are you a bot? 
- are you a human? 
- am I talking to a bot? 
- am I talking to a human? 

