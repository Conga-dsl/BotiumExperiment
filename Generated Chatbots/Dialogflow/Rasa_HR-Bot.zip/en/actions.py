# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import time
import requests

def time_validate(value:Text):
	return Text
	
def date_validate(value:Text):
	return Text
		
exit_process_db={
"exit process":["exit process","exit process"],
}
def exit_process_validate(value:Text):
	for input in exit_process_db:
		if value.lower() in exit_process_db[input]:
			return input
	return None
wellness_leave_info_db={
"staff wellness days":["staff wellness days","staff wellness days","wellness days","wellness days","wellnessinfo"],
}
def wellness_leave_info_validate(value:Text):
	for input in wellness_leave_info_db:
		if value.lower() in wellness_leave_info_db[input]:
			return input
	return None
family_medical_info_db={
"paid family and medical benefits":["paid family and medical benefits","paid family and medical benefits","paid family benefits","medical benefits","paid family and medical leave benefits","paid family and medical leave","family and medical benefits"],
}
def family_medical_info_validate(value:Text):
	for input in family_medical_info_db:
		if value.lower() in family_medical_info_db[input]:
			return input
	return None
emp_time_hr_db={
"employee time and hr actions":["employee time and hr actions","employee time and hr actions","employee time and hr","employee time","hr actions"],
}
def emp_time_hr_validate(value:Text):
	for input in emp_time_hr_db:
		if value.lower() in emp_time_hr_db[input]:
			return input
	return None
salary_db={
"salary":["salary","salary","current salary","compensation","annual salary"],
}
def salary_validate(value:Text):
	for input in salary_db:
		if value.lower() in salary_db[input]:
			return input
	return None
leave_balance_family_medical_db={
"paid family and medical leave balance":["paid family and medical leave balance","paid family and medical leave balance","leave balance paid family and medical leave","leave balance for paid family and medical leaves","leave balance medical leave","leave balance family leave","family leave balance","medical leave balance"],
}
def leave_balance_family_medical_validate(value:Text):
	for input in leave_balance_family_medical_db:
		if value.lower() in leave_balance_family_medical_db[input]:
			return input
	return None
leave_balance_wellness_db={
"wellness leave balance":["wellness leave balance","wellness leave balance","wellness","wellness balance","wellness days","wellness day","welness days"],
}
def leave_balance_wellness_validate(value:Text):
	for input in leave_balance_wellness_db:
		if value.lower() in leave_balance_wellness_db[input]:
			return input
	return None
emp_onboarding_db={
"employee onboarding":["employee onboarding","employee onboarding","onboarding"],
}
def emp_onboarding_validate(value:Text):
	for input in emp_onboarding_db:
		if value.lower() in emp_onboarding_db[input]:
			return input
	return None
hiring_recruitment_db={
"hiring and recruiting":["hiring and recruiting","hiring and recruiting","hiring","recruiting","recruitment"],
}
def hiring_recruitment_validate(value:Text):
	for input in hiring_recruitment_db:
		if value.lower() in hiring_recruitment_db[input]:
			return input
	return None
programming_language_db={
"python":["python","pytho","py"],
"javascript":["javascript","javascript","js"],
}
def programming_language_validate(value:Text):
	for input in programming_language_db:
		if value.lower() in programming_language_db[input]:
			return input
	return None
comp_info_db={
"compensation":["compensation","compensation","compensation process","compensation structure","compensation"],
}
def comp_info_validate(value:Text):
	for input in comp_info_db:
		if value.lower() in comp_info_db[input]:
			return input
	return None
hours_worked_db={
"hours worked":["hours worked","hours worked","time worked","time entry","total hours","total time"],
}
def hours_worked_validate(value:Text):
	for input in hours_worked_db:
		if value.lower() in hours_worked_db[input]:
			return input
	return None
volunteering_db={
"volunteering":["volunteering","volunteering","volunteering opportunities"],
}
def volunteering_validate(value:Text):
	for input in volunteering_db:
		if value.lower() in volunteering_db[input]:
			return input
	return None
service_request_db={
"service request":["service request","service request","service ticket","ticket","complaint"],
}
def service_request_validate(value:Text):
	for input in service_request_db:
		if value.lower() in service_request_db[input]:
			return input
	return None
merit_information_db={
"annual merit process":["annual merit process","annual merit process","merit process","merit","merit information"],
}
def merit_information_validate(value:Text):
	for input in merit_information_db:
		if value.lower() in merit_information_db[input]:
			return input
	return None
class ask_information_no_servreq_no_feedyesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "ask_information_no_servreq_no_feedyes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["ask_information_no_servreq_no_feedyes_empid","ask_information_no_servreq_no_feedyes_feedback"]
	def validate_ask_information_no_servreq_no_feedyes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'ask_information_no_servreq_no_feedyes_empid': None}
		return {'ask_information_no_servreq_no_feedyes_empid': value}
	def validate_ask_information_no_servreq_no_feedyes_feedback(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_feedback', tracker)
			return {'ask_information_no_servreq_no_feedyes_feedback': None}
		return {'ask_information_no_servreq_no_feedyes_feedback': value}
	
	def slot_mappings(self):
	
		return {
		"ask_information_no_servreq_no_feedyes_empid": [self.from_entity(entity="ask_information_no_servreq_no_feedyes_empid"),self.from_text()],
		"ask_information_no_servreq_no_feedyes_feedback": [self.from_entity(entity="ask_information_no_servreq_no_feedyes_feedback"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class raise_service_request_emailyes_feedbackyesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "raise_service_request_emailyes_feedbackyes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["raise_service_request_emailyes_feedbackyes_empid","raise_service_request_emailyes_feedbackyes_feedback"]
	def validate_raise_service_request_emailyes_feedbackyes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'raise_service_request_emailyes_feedbackyes_empid': None}
		return {'raise_service_request_emailyes_feedbackyes_empid': value}
	def validate_raise_service_request_emailyes_feedbackyes_feedback(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_feedback', tracker)
			return {'raise_service_request_emailyes_feedbackyes_feedback': None}
		return {'raise_service_request_emailyes_feedbackyes_feedback': value}
	
	def slot_mappings(self):
	
		return {
		"raise_service_request_emailyes_feedbackyes_empid": [self.from_entity(entity="raise_service_request_emailyes_feedbackyes_empid"),self.from_text()],
		"raise_service_request_emailyes_feedbackyes_feedback": [self.from_entity(entity="raise_service_request_emailyes_feedbackyes_feedback"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class retrieve_information_no_servreqyes_emailyes_feedyesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "retrieve_information_no_servreqyes_emailyes_feedyes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["retrieve_information_no_servreqyes_emailyes_feedyes_empid","retrieve_information_no_servreqyes_emailyes_feedyes_feedback"]
	def validate_retrieve_information_no_servreqyes_emailyes_feedyes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'retrieve_information_no_servreqyes_emailyes_feedyes_empid': None}
		return {'retrieve_information_no_servreqyes_emailyes_feedyes_empid': value}
	def validate_retrieve_information_no_servreqyes_emailyes_feedyes_feedback(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_feedback', tracker)
			return {'retrieve_information_no_servreqyes_emailyes_feedyes_feedback': None}
		return {'retrieve_information_no_servreqyes_emailyes_feedyes_feedback': value}
	
	def slot_mappings(self):
	
		return {
		"retrieve_information_no_servreqyes_emailyes_feedyes_empid": [self.from_entity(entity="retrieve_information_no_servreqyes_emailyes_feedyes_empid"),self.from_text()],
		"retrieve_information_no_servreqyes_emailyes_feedyes_feedback": [self.from_entity(entity="retrieve_information_no_servreqyes_emailyes_feedyes_feedback"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class detect_prog_languageForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "detect_prog_language_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_detect_prog_language_programming_language(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = programming_language_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_programming_language', tracker)
			return {'detect_prog_language_programming_language': None}
		return {'detect_prog_language_programming_language': value}
	
	def slot_mappings(self):
	
		return {
		"detect_prog_language_programming_language": [self.from_entity(entity="detect_prog_language_programming_language"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class servicereq_confirmationForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "servicereq_confirmation_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_servicereq_confirmation_service_request(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = service_request_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_service_request', tracker)
			return {'servicereq_confirmation_service_request': None}
		return {'servicereq_confirmation_service_request': value}
	
	def slot_mappings(self):
	
		return {
		"servicereq_confirmation_service_request": [self.from_entity(entity="servicereq_confirmation_service_request"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class retrieve_information_no_servreqyesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "retrieve_information_no_servreqyes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["retrieve_information_no_servreqyes_empid","retrieve_information_no_servreqyes_issue","retrieve_information_no_servreqyes_email"]
	def validate_retrieve_information_no_servreqyes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'retrieve_information_no_servreqyes_empid': None}
		return {'retrieve_information_no_servreqyes_empid': value}
	def validate_retrieve_information_no_servreqyes_issue(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_issue', tracker)
			return {'retrieve_information_no_servreqyes_issue': None}
		return {'retrieve_information_no_servreqyes_issue': value}
	def validate_retrieve_information_no_servreqyes_email(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_email', tracker)
			return {'retrieve_information_no_servreqyes_email': None}
		return {'retrieve_information_no_servreqyes_email': value}
	
	def slot_mappings(self):
	
		return {
		"retrieve_information_no_servreqyes_empid": [self.from_entity(entity="retrieve_information_no_servreqyes_empid"),self.from_text()],
		"retrieve_information_no_servreqyes_issue": [self.from_entity(entity="retrieve_information_no_servreqyes_issue"),self.from_text()],
		"retrieve_information_no_servreqyes_email": [self.from_entity(entity="retrieve_information_no_servreqyes_email"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class ask_information_no_servreq_yes_emailyesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "ask_information_no_servreq_yes_emailyes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["ask_information_no_servreq_yes_emailyes_empid"]
	def validate_ask_information_no_servreq_yes_emailyes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'ask_information_no_servreq_yes_emailyes_empid': None}
		return {'ask_information_no_servreq_yes_emailyes_empid': value}
	
	def slot_mappings(self):
	
		return {
		"ask_information_no_servreq_yes_emailyes_empid": [self.from_entity(entity="ask_information_no_servreq_yes_emailyes_empid"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class get_statusForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "get_status_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["get_status_userid"]
	def validate_get_status_userid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_userid', tracker)
			return {'get_status_userid': None}
		return {'get_status_userid': value}
	
	def slot_mappings(self):
	
		return {
		"get_status_userid": [self.from_entity(entity="get_status_userid"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class make_appointmentForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "make_appointment_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["make_appointment_date","make_appointment_time"]
	def validate_make_appointment_date(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = date_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_date', tracker)
			return {'make_appointment_date': None}
		return {'make_appointment_date': value}
	def validate_make_appointment_time(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = time_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_time', tracker)
			return {'make_appointment_time': None}
		return {'make_appointment_time': value}
	
	def slot_mappings(self):
	
		return {
		"make_appointment_date": [self.from_entity(entity="make_appointment_date"),self.from_text()],
		"make_appointment_time": [self.from_entity(entity="make_appointment_time"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class ask_informationForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "ask_information_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_ask_information_wellness_leave_info(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = wellness_leave_info_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_wellness_leave_info', tracker)
			return {'ask_information_wellness_leave_info': None}
		return {'ask_information_wellness_leave_info': value}
	def validate_ask_information_family_medical_info(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = family_medical_info_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_family_medical_info', tracker)
			return {'ask_information_family_medical_info': None}
		return {'ask_information_family_medical_info': value}
	def validate_ask_information_merit_information(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = merit_information_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_merit_information', tracker)
			return {'ask_information_merit_information': None}
		return {'ask_information_merit_information': value}
	def validate_ask_information_comp_info(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = comp_info_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_comp_info', tracker)
			return {'ask_information_comp_info': None}
		return {'ask_information_comp_info': value}
	def validate_ask_information_emp_time_hr(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = emp_time_hr_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_emp_time_hr', tracker)
			return {'ask_information_emp_time_hr': None}
		return {'ask_information_emp_time_hr': value}
	def validate_ask_information_volunteering(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = volunteering_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_volunteering', tracker)
			return {'ask_information_volunteering': None}
		return {'ask_information_volunteering': value}
	def validate_ask_information_emp_onboarding(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = emp_onboarding_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_emp_onboarding', tracker)
			return {'ask_information_emp_onboarding': None}
		return {'ask_information_emp_onboarding': value}
	def validate_ask_information_hiring_recruitment(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = hiring_recruitment_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_hiring_recruitment', tracker)
			return {'ask_information_hiring_recruitment': None}
		return {'ask_information_hiring_recruitment': value}
	def validate_ask_information_exit_process(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = exit_process_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_exit_process', tracker)
			return {'ask_information_exit_process': None}
		return {'ask_information_exit_process': value}
	
	def slot_mappings(self):
	
		return {
		"ask_information_wellness_leave_info": [self.from_entity(entity="ask_information_wellness_leave_info"),self.from_text()],
		"ask_information_family_medical_info": [self.from_entity(entity="ask_information_family_medical_info"),self.from_text()],
		"ask_information_merit_information": [self.from_entity(entity="ask_information_merit_information"),self.from_text()],
		"ask_information_comp_info": [self.from_entity(entity="ask_information_comp_info"),self.from_text()],
		"ask_information_emp_time_hr": [self.from_entity(entity="ask_information_emp_time_hr"),self.from_text()],
		"ask_information_volunteering": [self.from_entity(entity="ask_information_volunteering"),self.from_text()],
		"ask_information_emp_onboarding": [self.from_entity(entity="ask_information_emp_onboarding"),self.from_text()],
		"ask_information_hiring_recruitment": [self.from_entity(entity="ask_information_hiring_recruitment"),self.from_text()],
		"ask_information_exit_process": [self.from_entity(entity="ask_information_exit_process"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class raise_service_requestForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "raise_service_request_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["raise_service_request_empid","raise_service_request_issue","raise_service_request_email"]
	def validate_raise_service_request_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'raise_service_request_empid': None}
		return {'raise_service_request_empid': value}
	def validate_raise_service_request_issue(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_issue', tracker)
			return {'raise_service_request_issue': None}
		return {'raise_service_request_issue': value}
	def validate_raise_service_request_email(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_email', tracker)
			return {'raise_service_request_email': None}
		return {'raise_service_request_email': value}
	def validate_raise_service_request_service_request(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = service_request_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_service_request', tracker)
			return {'raise_service_request_service_request': None}
		return {'raise_service_request_service_request': value}
	
	def slot_mappings(self):
	
		return {
		"raise_service_request_empid": [self.from_entity(entity="raise_service_request_empid"),self.from_text()],
		"raise_service_request_issue": [self.from_entity(entity="raise_service_request_issue"),self.from_text()],
		"raise_service_request_email": [self.from_entity(entity="raise_service_request_email"),self.from_text()],
		"raise_service_request_service_request": [self.from_entity(entity="raise_service_request_service_request"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class capture_feedbackForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "capture_feedback_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["capture_feedback_empid","capture_feedback_feedback"]
	def validate_capture_feedback_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'capture_feedback_empid': None}
		return {'capture_feedback_empid': value}
	def validate_capture_feedback_feedback(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_feedback', tracker)
			return {'capture_feedback_feedback': None}
		return {'capture_feedback_feedback': value}
	
	def slot_mappings(self):
	
		return {
		"capture_feedback_empid": [self.from_entity(entity="capture_feedback_empid"),self.from_text()],
		"capture_feedback_feedback": [self.from_entity(entity="capture_feedback_feedback"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class detect_languageForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "detect_language_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_detect_language_language(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_language', tracker)
			return {'detect_language_language': None}
		return {'detect_language_language': value}
	
	def slot_mappings(self):
	
		return {
		"detect_language_language": [self.from_entity(entity="detect_language_language"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class ask_information_no_servreq_yesForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "ask_information_no_servreq_yes_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["ask_information_no_servreq_yes_empid","ask_information_no_servreq_yes_issue","ask_information_no_servreq_yes_email"]
	def validate_ask_information_no_servreq_yes_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'ask_information_no_servreq_yes_empid': None}
		return {'ask_information_no_servreq_yes_empid': value}
	def validate_ask_information_no_servreq_yes_issue(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_issue', tracker)
			return {'ask_information_no_servreq_yes_issue': None}
		return {'ask_information_no_servreq_yes_issue': value}
	def validate_ask_information_no_servreq_yes_email(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_email', tracker)
			return {'ask_information_no_servreq_yes_email': None}
		return {'ask_information_no_servreq_yes_email': value}
	
	def slot_mappings(self):
	
		return {
		"ask_information_no_servreq_yes_empid": [self.from_entity(entity="ask_information_no_servreq_yes_empid"),self.from_text()],
		"ask_information_no_servreq_yes_issue": [self.from_entity(entity="ask_information_no_servreq_yes_issue"),self.from_text()],
		"ask_information_no_servreq_yes_email": [self.from_entity(entity="ask_information_no_servreq_yes_email"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class log_statusForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "log_status_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["log_status_userid","log_status_status"]
	def validate_log_status_userid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_userid', tracker)
			return {'log_status_userid': None}
		return {'log_status_userid': value}
	def validate_log_status_status(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_status', tracker)
			return {'log_status_status': None}
		return {'log_status_status': value}
	
	def slot_mappings(self):
	
		return {
		"log_status_userid": [self.from_entity(entity="log_status_userid"),self.from_text()],
		"log_status_status": [self.from_entity(entity="log_status_status"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class retrieve_informationForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "retrieve_information_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["retrieve_information_empid"]
	def validate_retrieve_information_leave_balance_wellness(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = leave_balance_wellness_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_leave_balance_wellness', tracker)
			return {'retrieve_information_leave_balance_wellness': None}
		return {'retrieve_information_leave_balance_wellness': value}
	def validate_retrieve_information_leave_balance_family_medical(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = leave_balance_family_medical_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_leave_balance_family_medical', tracker)
			return {'retrieve_information_leave_balance_family_medical': None}
		return {'retrieve_information_leave_balance_family_medical': value}
	def validate_retrieve_information_empid(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = int (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_empid', tracker)
			return {'retrieve_information_empid': None}
		return {'retrieve_information_empid': value}
	def validate_retrieve_information_salary(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = salary_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_salary', tracker)
			return {'retrieve_information_salary': None}
		return {'retrieve_information_salary': value}
	def validate_retrieve_information_hours_worked(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = hours_worked_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_hours_worked', tracker)
			return {'retrieve_information_hours_worked': None}
		return {'retrieve_information_hours_worked': value}
	
	def slot_mappings(self):
	
		return {
		"retrieve_information_leave_balance_wellness": [self.from_entity(entity="retrieve_information_leave_balance_wellness"),self.from_text()],
		"retrieve_information_leave_balance_family_medical": [self.from_entity(entity="retrieve_information_leave_balance_family_medical"),self.from_text()],
		"retrieve_information_empid": [self.from_entity(entity="retrieve_information_empid"),self.from_text()],
		"retrieve_information_salary": [self.from_entity(entity="retrieve_information_salary"),self.from_text()],
		"retrieve_information_hours_worked": [self.from_entity(entity="retrieve_information_hours_worked"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class HttpRequest (Action):
	response = None
	def name(self) -> Text:
		return "action_HttpRequest"
		
	def run(self, dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		url = 'https://us-central1-questrom-hr-bot.cloudfunctions.net/hr-bot-function'
				
		auth={'', 'generator.impl.LiteralImpl@693afb44 (text: )'}
				
				
		HttpRequest.response = requests.post(url , auth=auth) 
	
class HttpResponse (Action):
	def name(self) -> Text:
		return "action_HttpResponse"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		response = HttpRequest.response			
		if response is None:
			return []	
		if response.status_code != 200:
			return []
		text = response.text
		dispatcher.utter_message(text)
		return []         
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

