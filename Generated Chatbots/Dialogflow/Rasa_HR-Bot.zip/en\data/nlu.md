## intent:raise_service_request_emailyes_feedbackyes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:make_appointment_yes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:ask_information_no_servreq_no
- thanks but no 
- no way 
- no 
- no no don't 
- na 
- no it isn't 
- don't 
- nah I'm good 
- no I cannot 
- I can't 
- nothing 
- no that's okay 
- no not really 
- nope not really 
- nope 
- thanks but not this time 
- I don't think so 
- I disagree 
- no maybe next time 
- not this time 
- no don't 
- no we are good 
- don't do it 
- no that's be all 
- not right now 
- nothing else thanks 
- no thanks 
- no that's ok 
- I don't want that 
- definitely not 
- nothing else 
- not 
- not at all 
- no never 
- never 
- no way no 
- not really 
- nah 
- I don't 
- I don't want 
- not today 
- not interested 
- no that's fine thank you 
- I'm not 
## intent:retrieve_information_no_servreqyes_emailyes_feedyes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:detect_prog_language
- I know  [javascript]{"entity": "detect_prog_language_programming_language","value":"JavaScript" }
- i know  [Py]{"entity": "detect_prog_language_programming_language","value":"Python" }
- i can code in  [python]{"entity": "detect_prog_language_programming_language","value":"Python" }
## intent:servicereq_confirmation
- Can you provide any  [written confirmation?]{"entity": "servicereq_confirmation_service_request","value":"" }
- Please provide  [confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- How to make sure that the  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" } is confirmed? 
- I want a confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
- Is there is any way to confirm my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }? 
- please provide an  [email confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- please provide an email confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
- Request for  [confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- How to confirm my  [request]{"entity": "servicereq_confirmation_service_request","value":"" }? 
- Any  [confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }? 
- [Email confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- [Service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
- Send me a  [confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- How to confirm my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }? 
- Can u provide an email confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }? 
- Require an email confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
- Send me an  [email confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }
- Can u provide an  [email confirmation]{"entity": "servicereq_confirmation_service_request","value":"" }? 
- I need an email confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
- Send me an email confirmation of my  [service request]{"entity": "servicereq_confirmation_service_request","value":"service request" }
## intent:Default_Welcome_Intent
- Good to see you 
- just going to say hi 
- heya 
- hello hi 
- howdy 
- hey there 
- hi there 
- greetings 
- hey 
- long time no see 
- Wellcome 
- hello 
- lovely day isn't it 
- I greet you 
- hello again 
- hi 
- hello there 
- a good day 
## intent:retrieve_information_no_servreqyes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:ask_information_no_servreq_yes_emailyes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:get_status
- get status nr  [85]{"entity": "get_status_userid" } 
- look up a value for user  [11]{"entity": "get_status_userid" } 
- look up my status 
- read status 
- read from database 
- get status 
## intent:make_appointment
- make a booking 
- book a slot 
- schedule a meeting 
- make an appointment 
- book me for  [Monday]{"entity": "make_appointment_date" }   [10am]{"entity": "make_appointment_time" } 
- Make appointment for  [1 october]{"entity": "make_appointment_date" } 
- book a meeting for  [tomorrow]{"entity": "make_appointment_date" } 
- i want make an appointment for  [tuesday]{"entity": "make_appointment_date" } 
## intent:ask_information
- What are  [staff wellness days]{"entity": "ask_information_wellness_leave_info","value":"staff wellness days" }? 
- Can you explain  [wellness days]{"entity": "ask_information_wellness_leave_info","value":"staff wellness days" }
- Can you explain me about  [staff wellness days]{"entity": "ask_information_wellness_leave_info","value":"staff wellness days" }
- What are  [wellness days]{"entity": "ask_information_wellness_leave_info","value":"staff wellness days" }? 
- Can you explain the  [recruiting process]{"entity": "ask_information_hiring_recruitment","value":"" }? 
- Can you explain the  [hiring process?]{"entity": "ask_information_hiring_recruitment","value":"" }
- What is the  [hiring process]{"entity": "ask_information_hiring_recruitment","value":"" }? 
- How  [hiring]{"entity": "ask_information_hiring_recruitment","value":"hiring and recruiting" } is done? 
- Can you explain the  [hiring and recruitment]{"entity": "ask_information_hiring_recruitment","value":"" } process? 
- [Hiring and recruitment]{"entity": "ask_information_hiring_recruitment","value":"" }
- Tell me about  [hiring and recruitment]{"entity": "ask_information_hiring_recruitment","value":"" } process 
- can you tell me about  [hiring and recruitment process?]{"entity": "ask_information_hiring_recruitment","value":"" }
- tell me about  [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" }
- [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" }
- Please explain the  [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" } process? 
- explain the  [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" } process? 
- What is the  [onboarding process]{"entity": "ask_information_emp_onboarding","value":"" }? 
- How I can  [contribute]{"entity": "ask_information_volunteering","value":"" }? 
- How I can contribute to  [society]{"entity": "ask_information_volunteering","value":"" }? 
- What are the  [opportunities]{"entity": "ask_information_volunteering","value":"" }? 
- What are the opportunities in which I can  [volunteer]{"entity": "ask_information_volunteering","value":"" }? 
- Can you explain the  [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" } process? 
- Can you explain about the  [volunteering opportunities]{"entity": "ask_information_volunteering","value":"volunteering" }? 
- [Volunteering]{"entity": "ask_information_volunteering","value":"volunteering" } opportunities 
- [Time management]{"entity": "ask_information_emp_time_hr","value":"" }
- [HR actions]{"entity": "ask_information_emp_time_hr","value":"employee time and hr actions" }
- Explain employee  [time management]{"entity": "ask_information_emp_time_hr","value":"" }? 
- tell me about  [volunteering]{"entity": "ask_information_volunteering","value":"volunteering" } opportunities 
- Can you tell me about the  [volunteering]{"entity": "ask_information_volunteering","value":"volunteering" } opportunities? 
- What are the  [volunteering]{"entity": "ask_information_volunteering","value":"volunteering" } opportunities? 
- Can you tell me about  [employee onboarding]{"entity": "ask_information_emp_onboarding","value":"employee onboarding" }? 
- Can you explain about  [hiring and recruitment]{"entity": "ask_information_hiring_recruitment","value":"" }? 
- Can you explain the  [exit process]{"entity": "ask_information_exit_process","value":"exit process" }? 
- [Compensation information]{"entity": "ask_information_comp_info","value":"" }
- can you explain the  [compensation process]{"entity": "ask_information_comp_info","value":"compensation" }? 
- Can you talk about the  [compensation info]{"entity": "ask_information_comp_info","value":"" }? 
- What is the  [compensation structure]{"entity": "ask_information_comp_info","value":"compensation" }? 
- What is the  [compensation process]{"entity": "ask_information_comp_info","value":"compensation" }? 
- What are the  [compensations]{"entity": "ask_information_comp_info","value":"" }? 
- Can you explain about the  [employee time and hr actions]{"entity": "ask_information_emp_time_hr","value":"employee time and hr actions" }? 
- What are the  [leave benefits]{"entity": "ask_information_family_medical_info","value":"" } on medical grounds? 
- What are the  [medical benefits]{"entity": "ask_information_family_medical_info","value":"paid family and medical benefits" }? 
- what are the  [medical leave benefits]{"entity": "ask_information_family_medical_info","value":"" }? 
-  Info about  [family and medical leave benefits]{"entity": "ask_information_family_medical_info","value":"" }? 
- [Merit information]{"entity": "ask_information_merit_information","value":"annual merit process" }
- Can you explain about the  [compensation]{"entity": "ask_information_comp_info","value":"compensation" }? 
- What is the  [annual merit process]{"entity": "ask_information_merit_information","value":"annual merit process" }? 
- What are paid  [family and medical leave benefits]{"entity": "ask_information_family_medical_info","value":"" }? 
## intent:raise_service_request
- I have a  [problem]{"entity": "raise_service_request_service_request","value":"" }
- I have an  [issue]{"entity": "raise_service_request_service_request","value":"" }
- I have a  [complaint]{"entity": "raise_service_request_service_request","value":"service request" }
- i want to raise a  [service request]{"entity": "raise_service_request_service_request","value":"service request" }
## intent:capture_feedback
- I want to provide my feedback 
## intent:detect_language
- I know a little  [mandarin]{"entity": "detect_language_language" } 
- I can speak  [spanish]{"entity": "detect_language_language" } 
- I know  [German]{"entity": "detect_language_language" } 
- i speak  [French]{"entity": "detect_language_language" } 
## intent:ask_information_no_servreq_yes
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- sg 
- yes that't ok 
- I agree 
- yes you can do it 
- I don't mind 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- I think so 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright why not 
- alright 
- right 
- it looks perfect 
- yes I can 
- yup 
- yep 
- confirm 
- absolutely 
## intent:log_status
- user  [12]{"entity": "log_status_userid" }  log my status 
- save to database 
- fill my diary 
- save my condition 
- write an entry 
- record my status 
- log my status 
## intent:retrieve_information
- please provide the  [time duration of my work]{"entity": "retrieve_information_hours_worked","value":"" }
- Please provide my  [salary details]{"entity": "retrieve_information_salary","value":"" }
- What  [balance leave for medical]{"entity": "retrieve_information_leave_balance_family_medical","value":"" } do I have? 
- I want my  [salary slip]{"entity": "retrieve_information_salary","value":"" }
- Please provide my  [salary slip]{"entity": "retrieve_information_salary","value":"" }
- [Duration]{"entity": "retrieve_information_hours_worked","value":"" } of my work this year 
- what is my  [medical leave balance]{"entity": "retrieve_information_leave_balance_family_medical","value":"paid family and medical leave balance" }? 
- I want to know the number of  [hours I have worked]{"entity": "retrieve_information_hours_worked","value":"" }  this year 
- I want to know  [my salary]{"entity": "retrieve_information_salary","value":"" }
- [My salary]{"entity": "retrieve_information_salary","value":"" }
- How much I  [earned]{"entity": "retrieve_information_salary","value":"" } this year? 
- My  [annual package]{"entity": "retrieve_information_salary","value":"" }? 
- What is my  [annual income]{"entity": "retrieve_information_leave_balance_wellness","value":"" }? 
- What is my  [income]{"entity": "retrieve_information_salary","value":"" } for this year? 
- Please provide details for my  [leave balance for paid family and medical leaves]{"entity": "retrieve_information_leave_balance_family_medical","value":"paid family and medical leave balance" }? 
- Can you tell me what my  [earning]{"entity": "retrieve_information_salary","value":"" } is? 
- How many leave I am left with for the  [wellness days]{"entity": "retrieve_information_leave_balance_wellness","value":"wellness leave balance" }? 
- Please provide the details for my  [earnings]{"entity": "retrieve_information_salary","value":"" }? 
- Please provide the details for my  [leave balance for wellness days]{"entity": "retrieve_information_leave_balance_wellness","value":"" }? 
- My  [wellness day leave balance]{"entity": "retrieve_information_leave_balance_wellness","value":"" }
- Can you tell me what my  [salary]{"entity": "retrieve_information_salary","value":"salary" } is? 
- how many  [hours]{"entity": "retrieve_information_hours_worked","value":"" } have I worked this year? 
- what is my  [salary]{"entity": "retrieve_information_salary","value":"salary" }? 
- What is my  [leave balance for paid family and medical leaves]{"entity": "retrieve_information_leave_balance_family_medical","value":"paid family and medical leave balance" }? 
- What is my  [leave balance for wellness days]{"entity": "retrieve_information_leave_balance_wellness","value":"" }? 

## synonym:exit process
- exit process


## synonym:staff wellness days
- staff wellness days
- wellness days
- Wellness Days
- WellnessInfo


## synonym:paid family and medical benefits
- paid family and medical benefits
- paid family benefits
- medical benefits
- paid family and medical leave benefits
- paid family and medical leave
- family and medical benefits


## synonym:employee time and hr actions
- employee time and hr actions
- employee time and hr
- employee time
- hr actions


## synonym:salary
- salary
- current salary
- compensation
- annual salary


## synonym:paid family and medical leave balance
- paid family and medical leave balance
- leave balance paid family and medical leave
- leave balance for paid family and medical leaves
- leave balance medical leave
- leave balance family leave
- family leave balance
- medical leave balance


## synonym:wellness leave balance
- wellness leave balance
- wellness
- wellness balance
- wellness days
- wellness day
- welness days


## synonym:employee onboarding
- employee onboarding
- onboarding


## synonym:hiring and recruiting
- hiring and recruiting
- hiring
- recruiting
- recruitment


## synonym:Python
- pytho
- py
## synonym:JavaScript
- JavaScript
- js


## synonym:compensation
- compensation
- compensation process
- compensation structure
- Compensation


## synonym:hours worked
- hours worked
- time worked
- time entry
- total hours
- total time


## synonym:volunteering
- volunteering
- volunteering opportunities


## synonym:service request
- service request
- service ticket
- ticket
- complaint


## synonym:annual merit process
- annual merit process
- merit process
- merit
- Merit Information


