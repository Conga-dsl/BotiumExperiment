## intent:Default_Welcome_Intent
- heya 
- hey there 
- hey 
- hi 
- long time no see 
- I greet you 
- just going to say hi 
- hello 
- howdy 
- hi there 
- hello hi 
- lovely day isn't it 
- hello there 
- hello again 
- a good day 
- greetings 
## intent:City_name
- Let's do  [Houston]{"entity": "City_name_city","value":"Houston" }
- I'll pick  [Houston]{"entity": "City_name_city","value":"Houston" }
- How about  [Chicago]{"entity": "City_name_city","value":"Chicago" }? 
- [New York]{"entity": "City_name_city","value":"New York" }
## intent:Trivia_answer
- How about  [Broadway]{"entity": "Trivia_answer_street","value":"Broadway" }
- I'm not sure but it might be  [Broadway]{"entity": "Trivia_answer_street","value":"Broadway" }
- Maybe it's  [Broadway]{"entity": "Trivia_answer_street","value":"Broadway" }
- I think it's  [Broadway]{"entity": "Trivia_answer_street","value":"Broadway" }
- [Broadway]{"entity": "Trivia_answer_street","value":"Broadway" }

## synonym:New York
- New York
- NYC
## synonym:Los Angeles
- Los Angeles
- LA
- L.A.
## synonym:Chicago
- Chicago
## synonym:Houston
- Houston


## synonym:Broadway
- Broadway


