## path_0
* bot_define	
	- utter_bot_defineTxtResp

## path_1
* fallback	
	- utter_fallbackTxtResp1

## path_2
* welcome	
	- utter_welcomeTxtResp1

## path_3
* bot_features	
	- utter_bot_featuresTxtResp1

## path_4
* bot_order	
	- bot_order_form
	- form{"name": "bot_order_form"}
	- form{"name": null}
	- utter_bot_orderTxtResp1
* bot_order___yes	
	- utter_bot_order___yesTxtResp1
* bot_order___yes___intermediate	
	- utter_bot_order___yes___intermediateTxtResp1

## path_5
* bot_order	
	- bot_order_form
	- form{"name": "bot_order_form"}
	- form{"name": null}
	- utter_bot_orderTxtResp1
* bot_order___yes	
	- utter_bot_order___yesTxtResp1
* bot_order___yes___advanced	
	- utter_bot_order___yes___advancedTxtResp1

## path_6
* bot_order	
	- bot_order_form
	- form{"name": "bot_order_form"}
	- form{"name": null}
	- utter_bot_orderTxtResp1
* bot_order___yes	
	- utter_bot_order___yesTxtResp1
* bot_order___yes___beginner	
	- utter_bot_order___yes___beginnerTxtResp1

## path_7
* bot_order	
	- bot_order_form
	- form{"name": "bot_order_form"}
	- form{"name": null}
	- utter_bot_orderTxtResp1
* bot_order___no	
	- utter_bot_order___noTxtResp1

