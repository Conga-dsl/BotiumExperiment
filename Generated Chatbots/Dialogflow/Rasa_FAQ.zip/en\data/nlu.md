## intent:bot_order___yes
- yes 
- do it 
- sure 
- exactly 
- confirm 
- of course 
- sounds good 
- that's correct 
- I don't mind 
- I agree 
## intent:bot_define
- what is a assistant app 
- who are bots 
- do you know anything about conversation apps 
- what are virtual assistants 
- what is a chatbot 
- tell me about virtual assistants 
- what are chatbots designed for 
- how does a bot work 
## intent:bot_order___no
- no 
- don't do it 
- definitely not 
- not really 
- thanks but no 
- not interested 
- I don't think so 
- I disagree 
- I don't want that 
## intent:bot_order___yes___intermediate
- Intermediate, 1-2 bots 
- Intermediate, built a couple of bots 
- 2-3 bots 
- I'm not very experienced 
- I've built a couple of bots 
- intermediate 
## intent:bot_order___yes___advanced
- advanced, several bots 
- I build bots every day 
- I've built 100+ bots 
- that's how I earn money 
- I do it for life 
- I'm a professional bot builder 
- it's my job 
- advanced 
## intent:bot_order___yes___beginner
- first time 
- don't know 
- don't know anything 
- not familiar 
- it's going to be my first bot 
- elementary 
- beginner 
- I'm just starting to dive into bot's world 
- just starting 
- I'm a beginner 
- I'm doing it for the first time 
## intent:fallback
- Nice shirt 
- Could you please show me some dog pictures 
- Navigate home 
- Who are US presidents? 
- What are the main cities in UK? 
- Need help with cooking recipes 
- I want to build a snowman 
- Tell me about the weather 
- What can you do to make me laugh 
- Show me your travel plans 
## intent:welcome
- Good day 
- Let's start 
- Hey 
- Hi 
- Hello 
- welcome 
## intent:bot_features
- show me your skills 
- what can you help me with 
- what are your main features 
- is there something I should know about your features 
- tell me some of your interesting capabilities 
- guide from your skills 
- how do we start working 
- what can I ask you about 
- what are you capable of 
- show me what you do 
- what can you do 
## intent:bot_order
- I'm about to start working on a  [fun]{"entity": "bot_order_industry","value":"entertainment" }  [Assistant]{"entity": "bot_order_platform" }  app 
- I'm working on a  [Slack]{"entity": "bot_order_platform" }  bot for a  [finance]{"entity": "bot_order_industry","value":"finance" } company 
- i'm building a bot for  [customer support]{"entity": "bot_order_industry","value":"support" }
- I need a bot for  [android]{"entity": "bot_order_platform" } 
- I want a  [facebook]{"entity": "bot_order_platform" }  bot 
- need help with an  [Assistant]{"entity": "bot_order_platform" }  conversation app for a  [travel]{"entity": "bot_order_industry","value":"travel" } company 
- I want to create a chatbot 
- how to create a chatbot for  [entertainment]{"entity": "bot_order_industry","value":"entertainment" } purposes 
- how to build a  [support]{"entity": "bot_order_industry","value":"support" } bot 
- where do people buy chatbots 
- I need a bot for a  [connected bot app]{"entity": "bot_order_industry","value":"connected home" }
- how to create a  [hotel booking]{"entity": "bot_order_industry","value":"hotel booking" } bot 
- how do I start 

## synonym:Assistant
- Actions on Google
- Assistant
- actions
- aog
## synonym:Facebook Messenger
- facebook
- facebook messenger
## synonym:Kik
- kik
## synonym:Line
- line
## synonym:Skype
- skype
## synonym:Slack
- Slack
## synonym:Telegram
- telegram
## synonym:Twitter
- twitter


## synonym:cars
- auto
- automotive
- cars
## synonym:connected home
- connected bot app
- connected home
## synonym:entertainment
- entertainment
- fun
## synonym:finance
- bank
- finance
- insurance
## synonym:flight booking
- flight
- flight booking
## synonym:food
- food
## synonym:hotel booking
- hotel
- hotel booking
## synonym:restaurant booking
- restaurant
- restaurant booking
## synonym:sport
- sport
## synonym:support
- crm
- customer support
- support
## synonym:travel
- travel


## synonym:Android SDK
- Android
- Android SDK
## synonym:C#
- C#
## synonym:C++
- C++
## synonym:HTML
- HTML
## synonym:JavaScript
- JavaScript
## synonym:iOS SDK
- iOS SDK
- ios
## synonym:java
- java
## synonym:node js
- node js
## synonym:php
- php
## synonym:python
- python
## synonym:ruby
- ruby
## synonym:unity
- unity




