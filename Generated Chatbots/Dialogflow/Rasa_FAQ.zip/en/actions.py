# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import time
import requests

def time_validate(value:Text):
	return Text
	
def date_validate(value:Text):
	return Text
		
integration_db={
"assistant":["assistant","actions on google","assistant","actions","aog"],
"facebook messenger":["facebook messenger","facebook","facebook messenger"],
"kik":["kik","kik"],
"line":["line","line"],
"skype":["skype","skype"],
"slack":["slack","slack"],
"telegram":["telegram","telegram"],
"twitter":["twitter","twitter"],
}
def integration_validate(value:Text):
	for input in integration_db:
		if value.lower() in integration_db[input]:
			return input
	return None
industry_db={
"cars":["cars","auto","automotive","cars"],
"connected home":["connected home","connected bot app","connected home"],
"entertainment":["entertainment","entertainment","fun"],
"finance":["finance","bank","finance","insurance"],
"flight booking":["flight booking","flight","flight booking"],
"food":["food","food"],
"hotel booking":["hotel booking","hotel","hotel booking"],
"restaurant booking":["restaurant booking","restaurant","restaurant booking"],
"sport":["sport","sport"],
"support":["support","crm","customer support","support"],
"travel":["travel","travel"],
}
def industry_validate(value:Text):
	for input in industry_db:
		if value.lower() in industry_db[input]:
			return input
	return None
sdk_db={
"android sdk":["android sdk","android","android sdk"],
"c#":["c#","c#"],
"c++":["c++","c++"],
"html":["html","html"],
"javascript":["javascript","javascript"],
"ios sdk":["ios sdk","ios sdk","ios"],
"java":["java","java"],
"node js":["node js","node js"],
"php":["php","php"],
"python":["python","python"],
"ruby":["ruby","ruby"],
"unity":["unity","unity"],
}
def sdk_validate(value:Text):
	for input in sdk_db:
		if value.lower() in sdk_db[input]:
			return input
	return None
def platform_validate(value:Text):
	return None
class bot_orderForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "bot_order_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["bot_order_industry","bot_order_platform"]
	def validate_bot_order_industry(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = industry_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_industry', tracker)
			return {'bot_order_industry': None}
		return {'bot_order_industry': value}
	def validate_bot_order_platform(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = platform_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_platform', tracker)
			return {'bot_order_platform': None}
		return {'bot_order_platform': value}
	
	def slot_mappings(self):
	
		return {
		"bot_order_industry": [self.from_entity(entity="bot_order_industry"),self.from_text()],
		"bot_order_platform": [self.from_entity(entity="bot_order_platform"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
	
	
	
	
	
	
	
	
	
	

