## intent:OrderTicket_Y_SelectSeat_Contact_N
- No 
- there is some mistake 
- it is wrong 
- It is not correct 
- I want change it 
- no 
- no no don't 
- na 
- no that's okay 
- no not really 
- nope not really 
- nah 
## intent:OrderTicket_Y
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- yes that't ok 
- I agree 
- yes you can do it 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- yes I agree 
- sure 
- sounds correct 
- sounds good 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright 
- right 
- yup 
- yep 
- confirm 
- absolutely 
## intent:OrderTicket_Y_SelectSeat
- It should be  [near the entrance]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"Back Section" }
- how about  [near the exit]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"" }
- [ground floor]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Standard" } and  [back]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"Back Section" } seat works for me 
- [Center]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"Center Section" } at the  [standard]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Standard" } section 
- [Center]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"Center Section" } point 
- [Front]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"" } side 
- [Balcony]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Balcony" } and  [front]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"" } side 
- [Back section]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"Back Section" } please 
- [Standard]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Standard" } works for me 
- I want  [front]{"entity": "OrderTicket_Y_SelectSeat_SeatSection","value":"" } seat at the  [balcony]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Balcony" }
- I prefer  [balcony]{"entity": "OrderTicket_Y_SelectSeat_seattype","value":"Balcony" }
## intent:OrderTicket_Y_SelectSeat_Contact
- [maryam aliakbari]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
- the number is  [4567891234]{"entity": "OrderTicket_Y_SelectSeat_Contact_phone_number" } 
- [maryam]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" }  and my phone is  [111-234-5678]{"entity": "OrderTicket_Y_SelectSeat_Contact_phone_number" } 
- here is my phone number  [111-111-1111]{"entity": "OrderTicket_Y_SelectSeat_Contact_phone_number" } 
- I want it in the name of  [maryam]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" }  and  [farzin]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" }  and  [ezekiel]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
- reserve the seats for  [Ezekiel Ayeni]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
- I am  [Maryam]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
- Yeah. set if for  [Farzin Valiloo]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
- Yes Sure. the order is in the name of  [Maryam Aliakbari]{"entity": "OrderTicket_Y_SelectSeat_Contact_person" } 
## intent:OrderTicket
- purchase ticket 
- buy ticket 
- buy a ticket 
- i want to buy a ticket 
- [gucci]{"entity": "OrderTicket_MovieName","value":"House of Gucci" } is my favourate movie 
- [wednesday]{"entity": "OrderTicket_OrderDay","value":"Next Wednesday" } works for me 
- [evening]{"entity": "OrderTicket_DayTime","value":"Evening" } I think 
- I want to buy  [3]{"entity": "OrderTicket_number" }  tickets for  [soho]{"entity": "OrderTicket_MovieName","value":"Last Night in Soho" } movie 
- i want to buy  [a]{"entity": "OrderTicket_number" }  ticket 
- I want to buy some tickets 
- just  [2]{"entity": "OrderTicket_number" }  please 
- [belfast]{"entity": "OrderTicket_MovieName","value":"" } in  [Odeon]{"entity": "OrderTicket_TheaterName","value":"Cineplex Odeon Devonshire Mall Cinema" } for morning  [sunday]{"entity": "OrderTicket_OrderDay","value":"Next Sunday" }
- [5]{"entity": "OrderTicket_number" }  tickets for  [Gucci]{"entity": "OrderTicket_MovieName","value":"House of Gucci" } in  [lakeshore]{"entity": "OrderTicket_TheaterName","value":"Imagine Cinemas Lakeshore" } cinema for  [tommorow]{"entity": "OrderTicket_OrderDay","value":"" }
- I like to watch  [soho]{"entity": "OrderTicket_MovieName","value":"Last Night in Soho" }
- i choose  [imagine]{"entity": "OrderTicket_TheaterName","value":"Imagine Cinemas Lakeshore" }
- I am going to order  [one]{"entity": "OrderTicket_number" }  ticket 
- [2]{"entity": "OrderTicket_number" }  tickets 
- [2]{"entity": "OrderTicket_number" }  please 
- [2]{"entity": "OrderTicket_number" }  tickets for  [spencer]{"entity": "OrderTicket_MovieName","value":"Spencer" } in  [silvercity]{"entity": "OrderTicket_TheaterName","value":"SilverCity Windsor Cinemas" } for the  [afternoon]{"entity": "OrderTicket_DayTime","value":"Afternoon" }  [today]{"entity": "OrderTicket_OrderDay","value":"Today" }
- I want to buy  [3]{"entity": "OrderTicket_number" }  tickets for  [gucci]{"entity": "OrderTicket_MovieName","value":"House of Gucci" } in cineplex for  [tomorrow]{"entity": "OrderTicket_OrderDay","value":"Tomorrow" }  [morning]{"entity": "OrderTicket_DayTime","value":"Morning" }
- I want to watch  [Gucci]{"entity": "OrderTicket_MovieName","value":"House of Gucci" }
- I want to buy tickets for  [3]{"entity": "OrderTicket_number" } 
- purchase some ticket 
- purchase  [a]{"entity": "OrderTicket_number" }  ticket 
- cinema ticket 
- Movie ticket 
- buy a film ticket 
- I wanna order Movie ticket 
- I want to watch a movie at the cinema 
- [monday]{"entity": "OrderTicket_OrderDay","value":"Next Monday" }  [afternon]{"entity": "OrderTicket_DayTime","value":"" } in  [odeon]{"entity": "OrderTicket_TheaterName","value":"Cineplex Odeon Devonshire Mall Cinema" } cinema  [no time for die]{"entity": "OrderTicket_MovieName","value":"No Time To Die" }
- [today]{"entity": "OrderTicket_OrderDay","value":"Today" }'s movie 
- [friday]{"entity": "OrderTicket_OrderDay","value":"Next Friday" }  [night]{"entity": "OrderTicket_DayTime","value":"Night" }  [soho]{"entity": "OrderTicket_MovieName","value":"Last Night in Soho" } at  [silvercity]{"entity": "OrderTicket_TheaterName","value":"SilverCity Windsor Cinemas" }
- I want to watch a film 
- I want to watch a movie 
- I want  [a]{"entity": "OrderTicket_number" }  ticket 
- Buy  [a]{"entity": "OrderTicket_number" }  ticket 
- I want to purchase  [a]{"entity": "OrderTicket_number" }  ticket 
- I want to buy movie ticket 
## intent:WelcomeIntent
- Hey I want to watch a movie in the cinema 
- hello hi 
- hey there 
- hi there 
- hey 
- hello 
- hi 
- hello there 
## intent:OrderTicket_Cancel
- I dont want it anymore 
- Just cancel the order 
- I change my mind 
- No just cancel it 
- stop 
- stop it 
- just forget about it 
- do nothing 
- cancel that 
- forget that 
- cancel 
- dismiss 
## intent:OrderTicket_Y_SelectSeat_Contact_Y
- yes 
- okay I will 
- why not 
- yes that's alright 
- yes I do 
- exactly 
- of course 
- yep that's ok 
- okay 
- ok 
- for sure 
- yes that't ok 
- I agree 
- that one works 
- that works 
- sure why not 
- perfect 
- yep that's right 
- yes I agree 
- sure 
- Yes. I confirm it 
- sounds correct 
- that's correct 
- go ahead 
- do it 
- it's fine 
- yeah 
- yes please 
- it's okay 
- alright 
- right 
- yup 
- yep 
- confirm 
- absolutely 
## intent:OrderTicket_N
- No i don't confirm 
- Could I change 
- Want to change 
- No please I want change it 
- no 
- no no don't 
- na 
- no it isn't 
- don't 
- no I cannot 
- I can't 
- nope 
- I don't think so 
- I disagree 
- definitely not 
- not 
- not at all 
- never 
- not really 
- nah 
- I don't 
- not today 
## intent:OrderTicket_Y_SelectSeat_Cancel
- stop 
- stop it 
- never mind 
- just forget about it 
- do nothing 
- skip 
- cancel that 
- forget that 
- cancel 
- dismiss 

## synonym:Dune
- Dune
- dun
## synonym:No Time To Die
- No Time To Die
- no time for die
- no time
- no die
## synonym:House of Gucci
- House of Gucci
- Gucci
- House for gucci
- gucci house
## synonym:Spencer
- Spencer
- spenser
## synonym:Last Night in Soho
- Last Night in Soho
- Soho
- last night soho


## synonym:SilverCity Windsor Cinemas
- SilverCity Windsor Cinemas
- Silvercity
- Silver
## synonym:Cineplex Odeon Devonshire Mall Cinema
- Cineplex Odeon Devonshire Mall Cinema
- Devonshire
- Cineplex
- odeon
- Divonshire Mall
- Cineplex Devonshire
- Cieplex odeon
## synonym:Imagine Cinemas Lakeshore
- Imagine Cinemas Lakeshore
- Imagine
- Lakeshore
- lakeshore imagine
- imagine lakeshore


## synonym:Today
- Today
- Now
## synonym:Tomorrow
- Tomorrow
- tommorrow
## synonym:Next Sunday
- Next Sunday
- Sunday
## synonym:Next Monday
- Next Monday
- Monday
## synonym:Next Tuseday
- Next Tuseday
- Tuseday
## synonym:Next Wednesday
- Next Wednesday
- wednesday
## synonym:Next Turseday
- Next Turseday
- Turseday
## synonym:Next Friday
- Next Friday
- Friday
## synonym:Next Saturday
- Next Saturday
- Saturday


## synonym:Morning
- Morning
## synonym:Afternoon
- Afternoon
## synonym:Evening
- Evening
## synonym:Night
- Night


## synonym:Standard
- Standard
- normal
- floor
- first floor
- Ground
- ground floor
## synonym:Balcony
- Balcony
- second floor
- VIP


## synonym:Front Section
- Front Section
- Closer to screen
- close to screen
- front line
- first rows
- near to exit
## synonym:Back Section
- Back Section
- Further
- further from screen
- as far as possible
- back row
- near the entry
- Back
- near the entrance
## synonym:Center Section
- Center Section
- Center
- Not too front not too back
- not too close


