# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import time
import requests

def time_validate(value:Text):
	return Text
	
def date_validate(value:Text):
	return Text
		
Movie_db={
"dune":["dune","dune","dun"],
"no time to die":["no time to die","no time to die","no time for die","no time","no die"],
"house of gucci":["house of gucci","house of gucci","gucci","house for gucci","gucci house"],
"spencer":["spencer","spencer","spenser"],
"last night in soho":["last night in soho","last night in soho","soho","last night soho"],
}
def Movie_validate(value:Text):
	for input in Movie_db:
		if value.lower() in Movie_db[input]:
			return input
	return None
Theater_db={
"silvercity windsor cinemas":["silvercity windsor cinemas","silvercity windsor cinemas","silvercity","silver"],
"cineplex odeon devonshire mall cinema":["cineplex odeon devonshire mall cinema","cineplex odeon devonshire mall cinema","devonshire","cineplex","odeon","divonshire mall","cineplex devonshire","cieplex odeon"],
"imagine cinemas lakeshore":["imagine cinemas lakeshore","imagine cinemas lakeshore","imagine","lakeshore","lakeshore imagine","imagine lakeshore"],
}
def Theater_validate(value:Text):
	for input in Theater_db:
		if value.lower() in Theater_db[input]:
			return input
	return None
OrderDay_db={
"today":["today","today","now"],
"tomorrow":["tomorrow","tomorrow","tommorrow"],
"next sunday":["next sunday","next sunday","sunday"],
"next monday":["next monday","next monday","monday"],
"next tuseday":["next tuseday","next tuseday","tuseday"],
"next wednesday":["next wednesday","next wednesday","wednesday"],
"next turseday":["next turseday","next turseday","turseday"],
"next friday":["next friday","next friday","friday"],
"next saturday":["next saturday","next saturday","saturday"],
}
def OrderDay_validate(value:Text):
	for input in OrderDay_db:
		if value.lower() in OrderDay_db[input]:
			return input
	return None
DayTime_db={
"morning":["morning","morning"],
"afternoon":["afternoon","afternoon"],
"evening":["evening","evening"],
"night":["night","night"],
}
def DayTime_validate(value:Text):
	for input in DayTime_db:
		if value.lower() in DayTime_db[input]:
			return input
	return None
SeatType_db={
"standard":["standard","standard","normal","floor","first floor","ground","ground floor"],
"balcony":["balcony","balcony","second floor","vip"],
}
def SeatType_validate(value:Text):
	for input in SeatType_db:
		if value.lower() in SeatType_db[input]:
			return input
	return None
SeatSection_db={
"front section":["front section","front section","closer to screen","close to screen","front line","first rows","near to exit"],
"back section":["back section","back section","further","further from screen","as far as possible","back row","near the entry","back","near the entrance"],
"center section":["center section","center section","center","not too front not too back","not too close"],
}
def SeatSection_validate(value:Text):
	for input in SeatSection_db:
		if value.lower() in SeatSection_db[input]:
			return input
	return None
class OrderTicket_Y_SelectSeatForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "OrderTicket_Y_SelectSeat_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["OrderTicket_Y_SelectSeat_seattype","OrderTicket_Y_SelectSeat_SeatSection"]
	def validate_OrderTicket_Y_SelectSeat_seattype(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = SeatType_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_seattype', tracker)
			return {'OrderTicket_Y_SelectSeat_seattype': None}
		return {'OrderTicket_Y_SelectSeat_seattype': value}
	def validate_OrderTicket_Y_SelectSeat_SeatSection(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = SeatSection_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_SeatSection', tracker)
			return {'OrderTicket_Y_SelectSeat_SeatSection': None}
		return {'OrderTicket_Y_SelectSeat_SeatSection': value}
	
	def slot_mappings(self):
	
		return {
		"OrderTicket_Y_SelectSeat_seattype": [self.from_entity(entity="OrderTicket_Y_SelectSeat_seattype"),self.from_text()],
		"OrderTicket_Y_SelectSeat_SeatSection": [self.from_entity(entity="OrderTicket_Y_SelectSeat_SeatSection"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class OrderTicket_Y_SelectSeat_ContactForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "OrderTicket_Y_SelectSeat_Contact_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["OrderTicket_Y_SelectSeat_Contact_person","OrderTicket_Y_SelectSeat_Contact_phone_number"]
	def validate_OrderTicket_Y_SelectSeat_Contact_person(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_person', tracker)
			return {'OrderTicket_Y_SelectSeat_Contact_person': None}
		return {'OrderTicket_Y_SelectSeat_Contact_person': value}
	def validate_OrderTicket_Y_SelectSeat_Contact_phone_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_phone_number', tracker)
			return {'OrderTicket_Y_SelectSeat_Contact_phone_number': None}
		return {'OrderTicket_Y_SelectSeat_Contact_phone_number': value}
	
	def slot_mappings(self):
	
		return {
		"OrderTicket_Y_SelectSeat_Contact_person": [self.from_entity(entity="OrderTicket_Y_SelectSeat_Contact_person"),self.from_text()],
		"OrderTicket_Y_SelectSeat_Contact_phone_number": [self.from_entity(entity="OrderTicket_Y_SelectSeat_Contact_phone_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class OrderTicketForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "OrderTicket_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["OrderTicket_TheaterName","OrderTicket_MovieName","OrderTicket_OrderDay","OrderTicket_DayTime","OrderTicket_number"]
	def validate_OrderTicket_TheaterName(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = Theater_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_TheaterName', tracker)
			return {'OrderTicket_TheaterName': None}
		return {'OrderTicket_TheaterName': value}
	def validate_OrderTicket_MovieName(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = Movie_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_MovieName', tracker)
			return {'OrderTicket_MovieName': None}
		return {'OrderTicket_MovieName': value}
	def validate_OrderTicket_OrderDay(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = OrderDay_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_OrderDay', tracker)
			return {'OrderTicket_OrderDay': None}
		return {'OrderTicket_OrderDay': value}
	def validate_OrderTicket_DayTime(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = DayTime_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_DayTime', tracker)
			return {'OrderTicket_DayTime': None}
		return {'OrderTicket_DayTime': value}
	def validate_OrderTicket_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_number', tracker)
			return {'OrderTicket_number': None}
		return {'OrderTicket_number': value}
	
	def slot_mappings(self):
	
		return {
		"OrderTicket_TheaterName": [self.from_entity(entity="OrderTicket_TheaterName"),self.from_text()],
		"OrderTicket_MovieName": [self.from_entity(entity="OrderTicket_MovieName"),self.from_text()],
		"OrderTicket_OrderDay": [self.from_entity(entity="OrderTicket_OrderDay"),self.from_text()],
		"OrderTicket_DayTime": [self.from_entity(entity="OrderTicket_DayTime"),self.from_text()],
		"OrderTicket_number": [self.from_entity(entity="OrderTicket_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
	
	
	
	
	
	
	
	
	
	
	

