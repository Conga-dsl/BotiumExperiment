# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import time
import requests

def time_validate(value:Text):
	return Text
	
def date_validate(value:Text):
	return Text
		
flavor_db={
"almond":["almond","almond","almond paste"],
"blueberry":["blueberry","blueberry"],
"caramel":["caramel","caramel"],
"cheese":["cheese","cheese"],
"cream cheese":["cream cheese","cream cheese"],
"hazelnut":["hazelnut","hazelnut"],
"peppermint":["peppermint","peppermint"],
"raspberry":["raspberry","raspberry"],
"strawberry":["strawberry","strawberry"],
"sugar-free vanilla":["sugar-free vanilla","sugar free vanilla","sugar-free vanilla"],
"vanilla":["vanilla","vanilla"],
}
def flavor_validate(value:Text):
	for input in flavor_db:
		if value.lower() in flavor_db[input]:
			return input
	return None
size_db={
"large":["large","big","huge","large"],
"medium":["medium","medium"],
"small":["small","little","short","small","tall"],
}
def size_validate(value:Text):
	for input in size_db:
		if value.lower() in size_db[input]:
			return input
	return None
snack_db={
"bagel":["bagel","bagel"],
"caesar salad":["caesar salad","caesar salad"],
"carrot cake":["carrot cake","carrot cake"],
"croissant":["croissant","croissant"],
"cupcake":["cupcake","cupcake"],
"danish":["danish","danish"],
"deep dish cake":["deep dish cake","deep dish cake"],
"doughnut":["doughnut","doughnut","donut"],
"greek salad":["greek salad","greek salad"],
"mediterranean salad":["mediterranean salad","mediterranean salad"],
"muffin":["muffin","muffin"],
"plum cake":["plum cake","plum cake"],
"salad":["salad","salad"],
"strudel":["strudel","strudel"],
}
def snack_validate(value:Text):
	for input in snack_db:
		if value.lower() in snack_db[input]:
			return input
	return None
delivery_pickup_db={
"delivery":["delivery","bring me","deliver","delivery"],
"pick-up":["pick-up","carry out","pick up","pick-up","pickup","to go","to-go"],
}
def delivery_pickup_validate(value:Text):
	for input in delivery_pickup_db:
		if value.lower() in delivery_pickup_db[input]:
			return input
	return None
iced_db={
"true":["true","chilled","cold","iced","on ice"],
}
def iced_validate(value:Text):
	for input in iced_db:
		if value.lower() in iced_db[input]:
			return input
	return None
milk_type_db={
"almond milk":["almond milk","almond"],
"cream":["cream","cream","half and half","half-and-half"],
"non fat milk":["non fat milk","non fat","non-fat","skinny"],
"regular milk":["regular milk","low fat","low-fat","lowfat","normal","regular","two percent"],
"soy milk":["soy milk","soy"],
}
def milk_type_validate(value:Text):
	for input in milk_type_db:
		if value.lower() in milk_type_db[input]:
			return input
	return None
topping_db={
"caramel":["caramel","caramel"],
"chocolate":["chocolate","chocolate","chocolate drizzle","chocolate syrup"],
"cinnamon":["cinnamon","cinnamon"],
"whipped cream":["whipped cream","whip","whipped cream"],
}
def topping_validate(value:Text):
	for input in topping_db:
		if value.lower() in topping_db[input]:
			return input
	return None
drink_db={
"americano":["americano","americano"],
"barista coffee":["barista coffee","barista coffee"],
"cappuccino":["cappuccino","cappuccino"],
"cocoa":["cocoa","cocoa"],
"espresso":["espresso","espresso"],
"espresso macchiato":["espresso macchiato","espresso macchiato"],
"espresso con panna":["espresso con panna","espresso con panna"],
"hot chocolate":["hot chocolate","hot chocolate"],
"latte":["latte","latte"],
"macchiato":["macchiato","macchiato"],
"tea":["tea","tea"],
"coffee":["coffee","coffee"],
}
def drink_validate(value:Text):
	for input in drink_db:
		if value.lower() in drink_db[input]:
			return input
	return None
class order_last_different_cardForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_last_different_card_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_order_last_different_card_card_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_card_number', tracker)
			return {'order_last_different_card_card_number': None}
		return {'order_last_different_card_card_number': value}
	
	def slot_mappings(self):
	
		return {
		"order_last_different_card_card_number": [self.from_entity(entity="order_last_different_card_card_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_snack_different_cardForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_snack_different_card_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_snack_different_card_card_number"]
	def validate_order_snack_different_card_card_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_card_number', tracker)
			return {'order_snack_different_card_card_number': None}
		return {'order_snack_different_card_card_number': value}
	
	def slot_mappings(self):
	
		return {
		"order_snack_different_card_card_number": [self.from_entity(entity="order_snack_different_card_card_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_lastForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_last_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_last_delivery_pickup"]
	def validate_order_last_delivery_pickup(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = delivery_pickup_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_delivery_pickup', tracker)
			return {'order_last_delivery_pickup': None}
		return {'order_last_delivery_pickup': value}
	
	def slot_mappings(self):
	
		return {
		"order_last_delivery_pickup": [self.from_entity(entity="order_last_delivery_pickup"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_gift_cardForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_gift_card_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_gift_card_card_balance","order_gift_card_delivery_pickup"]
	def validate_order_gift_card_card_balance(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_card_balance', tracker)
			return {'order_gift_card_card_balance': None}
		return {'order_gift_card_card_balance': value}
	def validate_order_gift_card_delivery_pickup(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = delivery_pickup_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_delivery_pickup', tracker)
			return {'order_gift_card_delivery_pickup': None}
		return {'order_gift_card_delivery_pickup': value}
	
	def slot_mappings(self):
	
		return {
		"order_gift_card_card_balance": [self.from_entity(entity="order_gift_card_card_balance"),self.from_text()],
		"order_gift_card_delivery_pickup": [self.from_entity(entity="order_gift_card_delivery_pickup"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_drink_different_cardForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_drink_different_card_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_drink_different_card_card_number"]
	def validate_order_drink_different_card_card_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_card_number', tracker)
			return {'order_drink_different_card_card_number': None}
		return {'order_drink_different_card_card_number': value}
	
	def slot_mappings(self):
	
		return {
		"order_drink_different_card_card_number": [self.from_entity(entity="order_drink_different_card_card_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_drinkForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_drink_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_drink_delivery_pickup","order_drink_drink","order_drink_size"]
	def validate_order_drink_delivery_pickup(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = delivery_pickup_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_delivery_pickup', tracker)
			return {'order_drink_delivery_pickup': None}
		return {'order_drink_delivery_pickup': value}
	def validate_order_drink_drink(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = drink_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_drink', tracker)
			return {'order_drink_drink': None}
		return {'order_drink_drink': value}
	def validate_order_drink_size(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = size_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_size', tracker)
			return {'order_drink_size': None}
		return {'order_drink_size': value}
	def validate_order_drink_iced(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = iced_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_iced', tracker)
			return {'order_drink_iced': None}
		return {'order_drink_iced': value}
	def validate_order_drink_amount(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_amount', tracker)
			return {'order_drink_amount': None}
		return {'order_drink_amount': value}
	def validate_order_drink_milk_type(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = milk_type_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_milk_type', tracker)
			return {'order_drink_milk_type': None}
		return {'order_drink_milk_type': value}
	
	def slot_mappings(self):
	
		return {
		"order_drink_delivery_pickup": [self.from_entity(entity="order_drink_delivery_pickup"),self.from_text()],
		"order_drink_drink": [self.from_entity(entity="order_drink_drink"),self.from_text()],
		"order_drink_size": [self.from_entity(entity="order_drink_size"),self.from_text()],
		"order_drink_iced": [self.from_entity(entity="order_drink_iced"),self.from_text()],
		"order_drink_amount": [self.from_entity(entity="order_drink_amount"),self.from_text()],
		"order_drink_milk_type": [self.from_entity(entity="order_drink_milk_type"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_snackForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_snack_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_snack_snack"]
	def validate_order_snack_snack(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = snack_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_snack', tracker)
			return {'order_snack_snack': None}
		return {'order_snack_snack': value}
	def validate_order_snack_size(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = size_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_size', tracker)
			return {'order_snack_size': None}
		return {'order_snack_size': value}
	def validate_order_snack_topping(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = topping_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_topping', tracker)
			return {'order_snack_topping': None}
		return {'order_snack_topping': value}
	def validate_order_snack_flavor(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = flavor_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_flavor', tracker)
			return {'order_snack_flavor': None}
		return {'order_snack_flavor': value}
	def validate_order_snack_amount(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_amount', tracker)
			return {'order_snack_amount': None}
		return {'order_snack_amount': value}
	def validate_order_snack_delivery_pickup(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = delivery_pickup_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_delivery_pickup', tracker)
			return {'order_snack_delivery_pickup': None}
		return {'order_snack_delivery_pickup': value}
	
	def slot_mappings(self):
	
		return {
		"order_snack_snack": [self.from_entity(entity="order_snack_snack"),self.from_text()],
		"order_snack_size": [self.from_entity(entity="order_snack_size"),self.from_text()],
		"order_snack_topping": [self.from_entity(entity="order_snack_topping"),self.from_text()],
		"order_snack_flavor": [self.from_entity(entity="order_snack_flavor"),self.from_text()],
		"order_snack_amount": [self.from_entity(entity="order_snack_amount"),self.from_text()],
		"order_snack_delivery_pickup": [self.from_entity(entity="order_snack_delivery_pickup"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_gift_card_different_cardForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_gift_card_different_card_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_gift_card_different_card_card_number"]
	def validate_order_gift_card_different_card_card_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_card_number', tracker)
			return {'order_gift_card_different_card_card_number': None}
		return {'order_gift_card_different_card_card_number': value}
	
	def slot_mappings(self):
	
		return {
		"order_gift_card_different_card_card_number": [self.from_entity(entity="order_gift_card_different_card_card_number"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

