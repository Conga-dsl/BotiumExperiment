## intent:order_drink___no
- definitely not 
- thanks but no 
- not interested 
- I don't want that 
- I don't think so 
- not really 
- don't do it 
- no 
- I disagree 
## intent:order_last_different_card
- don't do it 
- no  [333333333333]{"entity": "order_last_different_card_card_number" } 
- no 
- I don't think so 
- not really 
- thanks but no 
- not interested 
- I disagree 
- definitely not 
- I don't want that 
## intent:order_snack_different_card
- don't do it 
- I don't think so 
- no 
- I disagree 
- different 
- thanks but no 
- not really 
- another one 
- definitely not 
- not interested 
- different card 
- no, use  [22222222222]{"entity": "order_snack_different_card_card_number" } 
- I don't want that 
- another card 
## intent:order_snack___yes
- of course 
- sounds good 
- that's correct 
- confirm 
- sure 
- do it 
- I don't mind 
- I agree 
- yes 
- exactly 
## intent:order_last
- I want to have what I always have 
- can I have usual 
- can I  [pick up]{"entity": "order_last_delivery_pickup","value":"pick-up" } my last order 
- I want to order the same 
- [deliver]{"entity": "order_last_delivery_pickup","value":"delivery" } me my usual 
- as usual please 
- repeat my last order 
## intent:order_last_same_card
- same 
- of course 
- the same 
- yes 
- exactly 
- sounds good 
- same card 
- sure 
- do it 
- confirm 
- I don't mind 
- I agree 
- that's correct 
## intent:order_gift_card
- order gift card 
- I want to order a gift card with  [50$]{"entity": "order_gift_card_card_balance" }  on it 
- I'm looking for a present 
- I want to buy a gift card as a present 
- I want a gift card 
- [100 $]{"entity": "order_gift_card_card_balance" }  gift card please 
- I need a present 
- let's buy a gift card 
- [deliver]{"entity": "order_gift_card_delivery_pickup","value":"delivery" } the gift card to me 
## intent:order_gift_card_same_card
- that's correct 
- exactly 
- confirm 
- sounds good 
- usual card 
- I agree 
- yes 
- sure 
- same 
- of course 
- same card 
## intent:Default_Welcome_Intent
- a good day 
- hi there 
- hello there 
- hello again 
- I greet you 
- lovely day isn't it 
- long time no see 
- greetings 
- hey there 
- heya 
- just going to say hi 
- hello 
- hey 
- hi 
- welcome 
## intent:order_drink_different_card
- no this one  [11111111111]{"entity": "order_drink_different_card_card_number" } 
- I don't think so 
- don't do it 
- thanks but no 
- definitely not 
- different 
- I disagree 
- another one 
- no 
- I don't want that 
- not really 
- not interested 
## intent:order_drink
- do you have  [iced]{"entity": "order_drink_iced","value":"true" }  [latte]{"entity": "order_drink_drink","value":"Latte" }
- can I get a  [small]{"entity": "order_drink_size","value":"small" }  [iced]{"entity": "order_drink_iced","value":"true" }  [cappuccino]{"entity": "order_drink_drink","value":"Cappuccino" } with  [low fat]{"entity": "order_drink_milk_type","value":"regular milk" } milk 
- can I get  [tea]{"entity": "order_drink_drink","value":"Tea" }
- I want a  [cappuccino]{"entity": "order_drink_drink","value":"Cappuccino" } to go 
- [hot chocolate]{"entity": "order_drink_drink","value":"Hot Chocolate" }
- [2]{"entity": "order_drink_amount" }   [medium]{"entity": "order_drink_size","value":"medium" }  [macchiato]{"entity": "order_drink_drink","value":"Macchiato" }
- I want  [iced]{"entity": "order_drink_iced","value":"true" }  [coffee]{"entity": "order_drink_drink","value":"coffee" }
- I'd like a  [coffee]{"entity": "order_drink_drink","value":"coffee" }  [delivered]{"entity": "order_drink_delivery_pickup","value":"" }
- I need a cup of  [coffee]{"entity": "order_drink_drink","value":"coffee" }
- [2]{"entity": "order_drink_amount" }   [lattes]{"entity": "order_drink_drink","value":"" } please 
- some  [tea]{"entity": "order_drink_drink","value":"Tea" } please 
- I'd like to order a drink 
- people need  [coffee]{"entity": "order_drink_drink","value":"coffee" }
- [cappuccino]{"entity": "order_drink_drink","value":"Cappuccino" }
- [two]{"entity": "order_drink_amount" }   [medium]{"entity": "order_drink_size","value":"medium" }  [cappuccinos]{"entity": "order_drink_drink","value":"" } please 
- I'd like a  [coffee]{"entity": "order_drink_drink","value":"coffee" }  [to go]{"entity": "order_drink_delivery_pickup","value":"pick-up" }
- order  [coffee]{"entity": "order_drink_drink","value":"coffee" }
- can I get a  [small]{"entity": "order_drink_size","value":"small" }  [iced]{"entity": "order_drink_iced","value":"true" }  [latte]{"entity": "order_drink_drink","value":"Latte" } with  [low fat]{"entity": "order_drink_milk_type","value":"regular milk" } milk 
- can I get a  [huge]{"entity": "order_drink_size","value":"large" } cup of  [macchiato]{"entity": "order_drink_drink","value":"Macchiato" }
## intent:order_snack
- [3]{"entity": "order_snack_amount" }   [bagels]{"entity": "order_snack_snack","value":"" } please 
- [salad]{"entity": "order_snack_snack","value":"Salad" }
- [strudel]{"entity": "order_snack_snack","value":"Strudel" } with  [cheese]{"entity": "order_snack_flavor","value":"cheese" }
- get me a dessert 
- [bring me]{"entity": "order_snack_delivery_pickup","value":"delivery" } a  [bagel]{"entity": "order_snack_snack","value":"Bagel" }
- something to eat 
- [strawberry]{"entity": "order_snack_flavor","value":"strawberry" }  [cupcake]{"entity": "order_snack_snack","value":"Cupcake" } please 
- do you have  [croissants]{"entity": "order_snack_snack","value":"" }
- I'm hungry 
- I'd love to get a  [danish]{"entity": "order_snack_snack","value":"Danish" } with  [almond paste]{"entity": "order_snack_flavor","value":"almond" }
- how about a  [small]{"entity": "order_snack_size","value":"small" }  [bagel]{"entity": "order_snack_snack","value":"Bagel" }
- I want a  [muffin]{"entity": "order_snack_snack","value":"Muffin" }
- I'd love to get a  [bagel]{"entity": "order_snack_snack","value":"Bagel" } with  [cream cheese]{"entity": "order_snack_flavor","value":"cream cheese" }
- can I get  [three]{"entity": "order_snack_amount" }   [doughnuts]{"entity": "order_snack_snack","value":"" } please 
- [bagel]{"entity": "order_snack_snack","value":"Bagel" }
- I want a  [6]{"entity": "order_snack_amount" }   [huge]{"entity": "order_snack_size","value":"large" }  [chocolate]{"entity": "order_snack_topping","value":"chocolate" }  [doughnuts]{"entity": "order_snack_snack","value":"" } please 
- I want a  [huge]{"entity": "order_snack_size","value":"large" }  [chocolate]{"entity": "order_snack_topping","value":"chocolate" }  [doughnut]{"entity": "order_snack_snack","value":"Doughnut" }
## intent:order_snack_same_card
- sounds good 
- the same 
- same 
- of course 
- sure 
- I don't mind 
- exactly 
- that's correct 
- the same card 
- I agree 
- do it 
- confirm 
- yes 
## intent:order_gift_card_different_card
- different 
- definitely not 
- not interested 
- another one:  [1111222233334444]{"entity": "order_gift_card_different_card_card_number" } 
- no 
- I don't want that 
- thanks but no 
- different card 
- another one 
- I disagree 
- don't do it 
- no this one:  [11111111111111]{"entity": "order_gift_card_different_card_card_number" } 
- not really 
- I don't think so 
## intent:Default_Fallback_Intent
- can I get three bedroom apartments please 
- I don't want to order the same 
- I want to order a flight to New York 
- I want to be able to make a good cappuccino 
- I don't like cappuccino 
- I'd love to get a bag of almonds please 
- I want to order a credit card 
- I don't want to order a gift cards 

## synonym:almond
- almond
- almond paste
## synonym:blueberry
- blueberry
## synonym:caramel
- caramel
## synonym:cheese
- cheese
## synonym:cream cheese
- cream cheese
## synonym:hazelnut
- hazelnut
## synonym:peppermint
- peppermint
## synonym:raspberry
- raspberry
## synonym:strawberry
- strawberry
## synonym:sugar-free vanilla
- sugar free vanilla
- sugar-free vanilla
## synonym:vanilla
- vanilla


## synonym:large
- big
- huge
- large
## synonym:medium
- medium
## synonym:small
- little
- short
- small
- tall


## synonym:Bagel
- Bagel
## synonym:Caesar Salad
- Caesar Salad
## synonym:Carrot Cake
- Carrot Cake
## synonym:Croissant
- Croissant
## synonym:Cupcake
- Cupcake
## synonym:Danish
- Danish
## synonym:Deep Dish Cake
- Deep Dish Cake
## synonym:Doughnut
- Doughnut
- donut
## synonym:Greek Salad
- Greek Salad
## synonym:Mediterranean Salad
- Mediterranean Salad
## synonym:Muffin
- Muffin
## synonym:Plum Cake
- Plum Cake
## synonym:Salad
- Salad
## synonym:Strudel
- Strudel


## synonym:delivery
- bring me
- deliver
- delivery
## synonym:pick-up
- carry out
- pick up
- pick-up
- pickup
- to go
- to-go


## synonym:true
- chilled
- cold
- iced
- on ice


## synonym:almond milk
- almond
## synonym:cream
- cream
- half and half
- half-and-half
## synonym:non fat milk
- non fat
- non-fat
- skinny
## synonym:regular milk
- low fat
- low-fat
- lowfat
- normal
- regular
- two percent
## synonym:soy milk
- soy


## synonym:caramel
- caramel
## synonym:chocolate
- chocolate
- chocolate drizzle
- chocolate syrup
## synonym:cinnamon
- cinnamon
## synonym:whipped cream
- whip
- whipped cream


## synonym:Americano
- Americano
## synonym:Barista Coffee
- Barista Coffee
## synonym:Cappuccino
- Cappuccino
## synonym:Cocoa
- Cocoa
## synonym:Espresso
- Espresso
## synonym:Espresso Macchiato
- Espresso Macchiato
## synonym:Espresso con Panna
- Espresso con Panna
## synonym:Hot Chocolate
- Hot Chocolate
## synonym:Latte
- Latte
## synonym:Macchiato
- Macchiato
## synonym:Tea
- Tea
## synonym:coffee
- coffee


