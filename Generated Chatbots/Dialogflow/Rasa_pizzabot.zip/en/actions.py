# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import time
import requests

def time_validate(value:Text):
	return Text
	
def date_validate(value:Text):
	return Text
		
flavor_db={
"chocolate":["chocolate","chocolate","mocha"],
"vanilla":["vanilla","vanilla"],
"strawberry":["strawberry","strawberry"],
"caramel":["caramel","caramel"],
"blueberry":["blueberry","blueberry"],
"raspberry":["raspberry","raspberry"],
"peppermint":["peppermint","peppermint"],
}
def flavor_validate(value:Text):
	for input in flavor_db:
		if value.lower() in flavor_db[input]:
			return input
	return None
size_db={
"small":["small","small"],
"medium":["medium","medium"],
"large":["large","large"],
}
def size_validate(value:Text):
	for input in size_db:
		if value.lower() in size_db[input]:
			return input
	return None
def drink_composite_validate(value:Text):
	return None
pizza_topping_db={
"pepper":["pepper","pepper"],
"mushroom":["mushroom","mushroom","mushrooms"],
"bacon":["bacon","bacon, bacon pieces, bacon bits, bacon slices"],
"vegetarian":["vegetarian","vegetarian","veggie"],
"cheese":["cheese","cheese"],
"jalapeno":["jalapeno","jalapeno","hot peppers"],
"sausage":["sausage","sausage"],
"onion":["onion","onion"],
"ham":["ham","ham"],
"pineapple":["pineapple","pineapple"],
"chicken":["chicken","chicken"],
}
def pizza_topping_validate(value:Text):
	for input in pizza_topping_db:
		if value.lower() in pizza_topping_db[input]:
			return input
	return None
milk_type_db={
"regular milk":["regular milk","regular milk","regular"],
"low fat milk":["low fat milk","low fat milk","low fat milk , low fat, low-fat, skim, 2%"],
"non fat milk":["non fat milk","non fat milk","non fat milk, non fat, non-fat, skinny"],
"soy milk":["soy milk","soy milk","soy milk, soy"],
}
def milk_type_validate(value:Text):
	for input in milk_type_db:
		if value.lower() in milk_type_db[input]:
			return input
	return None
drink_db={
"smoothie":["smoothie","smoothie"],
"milkshake":["milkshake","milkshake"],
}
def drink_validate(value:Text):
	for input in drink_db:
		if value.lower() in drink_db[input]:
			return input
	return None
class order_drinkForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_drink_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_order_drink_drink_composite(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = drink_composite_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_drink_composite', tracker)
			return {'order_drink_drink_composite': None}
		return {'order_drink_drink_composite': value}
	def validate_order_drink_drink(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = drink_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_drink', tracker)
			return {'order_drink_drink': None}
		return {'order_drink_drink': value}
	def validate_order_drink_number(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		try:
			parseValue = float (value)
		except ValueError:
			parseValue = None
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_number', tracker)
			return {'order_drink_number': None}
		return {'order_drink_number': value}
	def validate_order_drink_size(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = size_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_size', tracker)
			return {'order_drink_size': None}
		return {'order_drink_size': value}
	def validate_order_drink_percentage(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_percentage', tracker)
			return {'order_drink_percentage': None}
		return {'order_drink_percentage': value}
	
	def slot_mappings(self):
	
		return {
		"order_drink_drink_composite": [self.from_entity(entity="order_drink_drink_composite"),self.from_text()],
		"order_drink_drink": [self.from_entity(entity="order_drink_drink"),self.from_text()],
		"order_drink_number": [self.from_entity(entity="order_drink_number"),self.from_text()],
		"order_drink_size": [self.from_entity(entity="order_drink_size"),self.from_text()],
		"order_drink_percentage": [self.from_entity(entity="order_drink_percentage"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class order_pizzaForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "order_pizza_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return ["order_pizza_time","order_pizza_date","order_pizza_pizza_topping","order_pizza_size"]
	def validate_order_pizza_time(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = time_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_time', tracker)
			return {'order_pizza_time': None}
		return {'order_pizza_time': value}
	def validate_order_pizza_date(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = date_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_date', tracker)
			return {'order_pizza_date': None}
		return {'order_pizza_date': value}
	def validate_order_pizza_pizza_topping(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = pizza_topping_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_pizza_topping', tracker)
			return {'order_pizza_pizza_topping': None}
		return {'order_pizza_pizza_topping': value}
	def validate_order_pizza_size(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = size_validate(value)
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_size', tracker)
			return {'order_pizza_size': None}
		return {'order_pizza_size': value}
	
	def slot_mappings(self):
	
		return {
		"order_pizza_time": [self.from_entity(entity="order_pizza_time"),self.from_text()],
		"order_pizza_date": [self.from_entity(entity="order_pizza_date"),self.from_text()],
		"order_pizza_pizza_topping": [self.from_entity(entity="order_pizza_pizza_topping"),self.from_text()],
		"order_pizza_size": [self.from_entity(entity="order_pizza_size"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
class opening_hoursForm (FormAction):
	def name(self):
		# type: () -> Text
			"""Unique identifier of the form"""
			return "opening_hours_form"
				
	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""
		
		return []
	def validate_opening_hours_date_time(self, value: Text,dispatcher: CollectingDispatcher,tracker: Tracker,domain: Dict[Text, Any]) -> Dict[Text, Any]:
		parseValue = value
		if parseValue is None:
			dispatcher.utter_message('utter_wrong_date_time', tracker)
			return {'opening_hours_date_time': None}
		return {'opening_hours_date_time': value}
	
	def slot_mappings(self):
	
		return {
		"opening_hours_date_time": [self.from_entity(entity="opening_hours_date_time"),self.from_text()],}
	def submit(
		self,
		dispatcher: CollectingDispatcher,
		tracker: Tracker,
		domain: Dict[Text, Any],
		) -> List[Dict]:
		"""Define what the form has to do after all required slots are filled"""
		return []
	
	
	
	
	

