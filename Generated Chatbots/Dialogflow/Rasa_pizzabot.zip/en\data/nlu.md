## intent:Default_Welcome_Intent
- just going to say hi 
- heya 
- hello hi 
- howdy 
- hey there 
- hi there 
- greetings 
- hey 
- long time no see 
- hello 
- lovely day isn't it 
- I greet you 
- hello again 
- hi 
- hello there 
- a good day 
## intent:order_drink
- one  [chocolate smoothie]{"entity": "order_drink_drink_composite" }  please 
- I want one  [vanilla milkshake]{"entity": "order_drink_drink_composite" }  with  [2%]{"entity": "order_drink_percentage" }  milk 
- i want a  [small]{"entity": "order_drink_size","value":"small" }  [strawberry smoothie]{"entity": "order_drink_drink_composite" } 
- [two]{"entity": "order_drink_number" }   [large]{"entity": "order_drink_size","value":"large" }  [soy milk chocolate milkshakes]{"entity": "order_drink_drink_composite" } 
- i'd like to order a rasberry  [smoothie]{"entity": "order_drink_drink","value":"smoothie" } please 
- I would like a  [mocha smoothie]{"entity": "order_drink_drink_composite" } 
## intent:order_pizza
- I want to order a  [large]{"entity": "order_pizza_size","value":"large" } pizza 
- I want a  [chicken]{"entity": "order_pizza_pizza_topping","value":"chicken" } pizza 
- I'd like to order a pizza for pickup in  [1 hour]{"entity": "order_pizza_time" } 
- I want a pizza with  [pepper]{"entity": "order_pizza_pizza_topping","value":"pepper" } and mushroom 
- I'd like a  [small]{"entity": "order_pizza_size","value":"small" } pizza with  [mushrooms]{"entity": "order_pizza_pizza_topping","value":"mushroom" }
- I want to order a  [small]{"entity": "order_pizza_size","value":"small" } pizza with  [chicken]{"entity": "order_pizza_pizza_topping","value":"chicken" } only 
- I want to order a  [cheese]{"entity": "order_pizza_pizza_topping","value":"cheese" } pizza for  [1 PM]{"entity": "order_pizza_time" }   [tomorrow]{"entity": "order_pizza_date" } 
- can I order a  [cheese]{"entity": "order_pizza_pizza_topping","value":"cheese" } pizza for pickup  [today]{"entity": "order_pizza_date" }  at  [noon]{"entity": "order_pizza_time" }  ? 
## intent:opening_hours
- When do you close ? 
- Are you open  [today]{"entity": "opening_hours_date_time" }  ? 
- Are you open right now ? 
- What time do you open ? 

## synonym:chocolate
- chocolate
- mocha
## synonym:vanilla
- vanilla
## synonym:strawberry
- strawberry
## synonym:caramel
- caramel
## synonym:blueberry
- blueberry
## synonym:raspberry
- raspberry
## synonym:peppermint
- peppermint


## synonym:small
- small
## synonym:medium
- medium
## synonym:large
- large




## synonym:pepper
- pepper
## synonym:mushroom
- mushroom
- mushrooms
## synonym:bacon
- bacon, bacon pieces, bacon bits, bacon slices
## synonym:vegetarian
- vegetarian
- veggie
## synonym:cheese
- cheese
## synonym:jalapeno
- jalapeno
- hot peppers
## synonym:sausage
- sausage
## synonym:onion
- onion
## synonym:ham
- ham
## synonym:pineapple
- pineapple
## synonym:chicken
- chicken


## synonym:regular milk
- regular milk
- regular
## synonym:low fat milk
- low fat milk
- low fat milk , low fat, low-fat, skim, 2%
## synonym:non fat milk
- non fat milk
- non fat milk, non fat, non-fat, skinny
## synonym:soy milk
- soy milk
- soy milk, soy


## synonym:smoothie
- smoothie
## synonym:milkshake
- milkshake


