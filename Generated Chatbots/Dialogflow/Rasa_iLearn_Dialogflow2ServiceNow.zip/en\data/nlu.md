## intent:Default_Welcome_Intent
- just going to say hi 
- heya 
- hello hi 
- howdy 
- hey there 
- hi there 
- greetings 
- hey 
- long time no see 
- hello 
- lovely day isn't it 
- I greet you 
- hello again 
- hi 
- hello there 
- a good day 
## intent:incident_status
- check on status of my ticket 
- i would like status on my incident 
- what is the status of my ticket 
## intent:incident_status_number
- my ticket number is INC [0010029]{"entity": "incident_status_number_number" } 
- my ticket # is  [59]{"entity": "incident_status_number_number" } 
- the ticket number is INC [0010060]{"entity": "incident_status_number_number" } 
- my ticket number is  [30]{"entity": "incident_status_number_number" } 
## intent:incident_create_details
- [Bud Richardson]{"entity": "incident_create_details_username" }  and  [my mobile phone will not turn on]{"entity": "incident_create_details_description" } 
- [Margaret Grey]{"entity": "incident_create_details_username" } , my  [laptop has a blue screen]{"entity": "incident_create_details_description" } 
- [David Miller]{"entity": "incident_create_details_username" }  and need to  [reset my password]{"entity": "incident_create_details_description" } 
## intent:incident_create
- helpdesk support 
- create an incident 
- i need to open a ticket 

