## path_0
* vehicle_status	
	- utter_vehicle_statusTxtResp1

## path_1
* Default_Welcome_Intent	
	- utter_Default_Welcome_IntentTxtResp1

## path_2
* exit	
	- utter_exitTxtResp1

## path_3
* Notify_Authorities	
	- utter_Notify_AuthoritiesTxtResp1

## path_4
* Notify_Family	
	- utter_Notify_FamilyTxtResp1

## path_5
* Help	
	- utter_HelpTxtResp1

## path_6
* Safe_route	
	- utter_Safe_routeTxtResp1

## path_7
* Hotspots	
	- utter_HotspotsTxtResp1

## path_8
* Default_Fallback_Intent	
	- utter_Default_Fallback_IntentTxtResp1

## path_9
* Notify_neighbours	
	- utter_Notify_neighboursTxtResp1

