## intent:vehicle_status
- Monitor Vehicle Health 
- show me on board diagnostics of my vehicle 
- check my vehicle status 
## intent:Default_Welcome_Intent
- hello 
- hey 
- just going to say hi 
- heya 
- hey there 
- hi 
- hello again 
- howdy 
- long time no see 
- lovely day isn't it 
- hi there 
- hello hi 
- hello there 
- I greet you 
- greetings 
- a good day 
## intent:exit
- bye! 
- goodbye 
- goodbye! 
- see ya 
- bye 
## intent:Notify_Authorities
- Alert Authorities 
- Alert the police 
- Call the police 
## intent:Notify_Family
- Call my emergency contacts 
- Alert my family 
- Notify Family 
## intent:Help
- Help! 
## intent:Safe_route
- Find Safe Route 
## intent:Hotspots
- Nearby police stations 
- Nearest Hotspots 
## intent:Notify_neighbours
- Notify People Around You 

