## intent:Laptop_Checkout
- Laptop Checkout 
## intent:Transfer_Student
- Transfer Student 
## intent:Cost_to_Attend
- Cost to Attend 
## intent:Default_Welcome_Intent_-_Admission_-_Sign_Up_for_orientation
- Sign Up for orientation 
## intent:Download_Software
- Download Software 
## intent:Knowledge_base_articles
- knowledge base articles 
## intent:Freshman_&_First-Time
- Freshman & First-Time 
## intent:Support_Bot
- support 
- I want to talk to support 
## intent:Default_Welcome_Intent
- just going to say hi 
- heya 
- hello hi 
- howdy 
- hey there 
- hi there 
- greetings 
- hey 
- long time no see 
- hello 
- lovely day isn't it 
- I greet you 
- hello again 
- hi 
- hello there 
- a good day 
## intent:Veteran_Admission
- Veteran Admission 
## intent:Virtual_Labs
- Virtual Labs 
## intent:Main_Menu
- Main Menu 
## intent:Transfer_to_Advise_Bot
- Change my major 
- Change of Major 
- Grad Check 
- Holds 
## intent:Technical_Support
- Technical Support 
## intent:Admission_Deadlines
- Admission Deadlines 

